/* "View Project" cursor pill. Any element with data-cursor="Label" shows a pill that trails the
   pointer (hover-capable fine pointers only). Keyboard users get the same label via the link's
   accessible name, so this is purely decorative. */
(() => {
  'use strict';
  const TS = window.TS || {};
  const fine = matchMedia('(hover: hover) and (pointer: fine)');
  TS.ready && TS.ready(() => {
    if (!fine.matches) return;
    const pill = document.createElement('div');
    pill.className = 'cursor-pill';
    pill.setAttribute('aria-hidden', 'true');
    pill.innerHTML = '<span class="cursor-pill__label"></span><span class="cursor-pill__icon"><svg viewBox="0 0 16 16"><path d="M4.5 11.5 11.5 4.5M5.5 4.5h6v6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></span>';
    document.body.appendChild(pill);
    const label = pill.querySelector('.cursor-pill__label');
    let x = -200, y = -200, cx = x, cy = y, active = null, raf = 0;
    const smooth = !(TS.reduced && TS.reduced());
    const tick = () => {
      cx += (x - cx) * (smooth ? 0.2 : 1);
      cy += (y - cy) * (smooth ? 0.2 : 1);
      pill.style.transform = `translate3d(${cx}px, ${cy}px, 0)`;
      raf = Math.abs(x - cx) + Math.abs(y - cy) > 0.1 ? requestAnimationFrame(tick) : 0;
    };
    const move = e => { x = e.clientX; y = e.clientY; if (!raf) raf = requestAnimationFrame(tick); };
    document.addEventListener('pointermove', e => {
      move(e);
      const t = e.target.closest('[data-cursor]');
      if (t !== active) {
        active = t;
        if (t) { label.textContent = t.dataset.cursor || 'View Project'; pill.classList.toggle('is-external', t.dataset.cursorExternal === 'true'); }
        pill.classList.toggle('is-on', !!t);
        document.documentElement.classList.toggle('has-cursor-pill', !!t);
      }
    }, { passive: true });
    document.addEventListener('pointerleave', () => { active = null; pill.classList.remove('is-on'); }, { passive: true });
    window.addEventListener('scroll', () => {
      if (!active) return;
      const t = document.elementFromPoint(x, y);
      if (!t || !t.closest('[data-cursor]')) { active = null; pill.classList.remove('is-on'); }
    }, { passive: true });
  });
})();
