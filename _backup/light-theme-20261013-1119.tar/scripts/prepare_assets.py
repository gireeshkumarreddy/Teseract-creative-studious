"""Prepare web assets from the audited public source manifest. No image invention or upscaling."""
import concurrent.futures, hashlib, io, json, pathlib, urllib.request
from PIL import Image, ImageOps

ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = ROOT / 'dist/assets'
OUT.mkdir(parents=True, exist_ok=True)
SOURCES = json.loads((ROOT / 'scripts/asset-sources.json').read_text())

def prepare(item):
    url, name = item['url'], item['name']
    if item.get('vector') or item.get('font'):
        data = urllib.request.urlopen(url, timeout=60).read()
        (OUT / name).write_bytes(data)
        return {**item, 'file': 'assets/' + name, 'bytes': len(data)}
    data = urllib.request.urlopen(url, timeout=90).read()
    img = ImageOps.exif_transpose(Image.open(io.BytesIO(data)))
    if img.mode not in ('RGB', 'RGBA'): img = img.convert('RGBA' if 'transparency' in img.info else 'RGB')
    widths = sorted(set(min(w, img.width) for w in (640, 1280, 2560, 3840)))
    variants = []
    for width in widths:
        height = round(img.height * width / img.width)
        path = OUT / f'{name}-{width}.webp'
        view = img if width == img.width else img.resize((width, height), Image.Resampling.LANCZOS)
        view.save(path, 'WEBP', quality=88, method=5)
        variants.append({'file': 'assets/' + path.name, 'width': width, 'height': height, 'bytes': path.stat().st_size})
    return {**item, 'native_width': img.width, 'native_height': img.height, 'sha256': hashlib.sha256(data).hexdigest(), 'variants': variants}

if __name__ == '__main__':
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        futures = {pool.submit(prepare, item): item for item in SOURCES}
        for future in concurrent.futures.as_completed(futures):
            item = futures[future]
            try:
                result = future.result()
                results.append(result)
                print('Prepared', item['name'], flush=True)
            except Exception as exc:
                print('FAILED', item['name'], repr(exc), flush=True)
                raise
    results.sort(key=lambda item: item['name'])
    (ROOT / 'scripts/asset-manifest.json').write_text(json.dumps(results, indent=2))
    print('ASSETS', len(results), 'BYTES', sum(p.stat().st_size for p in OUT.iterdir()), flush=True)
