"""THE WORK page (/work/).

Hero (reference page-hero lockup + project-name marquee) -> intro lines -> index of all
projects -> how a case study is structured -> "your project could be next" slot.

Project tiles follow the ZIP home gallery ("studio second section"): image at its native
aspect ratio inside .reveal-image (scale 1.1 -> 1 over 1.3 s + fade), hover zoom 1.018 over
1.3 s, square black mono caption box whose title/industry lines roll on hover, plus the
"View Project" cursor through lib.project_tag. The tile helpers are reused by pages/project.py.
"""
import lib
from lib import E, fmt, ICONS, roll, button, pill_label
import content
import projects as P

W = content.WORK

# Rendered widths (container = 1344 px at >=1440, viewport - 2*40 on tablet, - 2*16 on phone).
SIZES_FULL = '(min-width:1440px) 1344px, (min-width:800px) calc(100vw - 80px), calc(100vw - 32px)'
SIZES_HALF = '(min-width:1440px) 664px, (min-width:800px) calc(50vw - 48px), calc(100vw - 32px)'


def services(p):
    """Services as listed in the portfolio data. Split on ' / ' (spaced) so names that contain a
    slash themselves, such as 'UI/UX Design', stay whole."""
    return [s.strip() for s in (p.get('services') or '').split(' / ') if s.strip()]


def _aspect(name):
    a = lib.ASSETS[name]
    return a['native_width'] / a['native_height']


def lead_mark(ctx):
    """Brand avatar used as the leading visual of dark CTA buttons (reference Contact button)."""
    return lib.img(ctx, 'assets/brand/logo-mark-3d-on-white.webp', '', w=28, h=28)


def caption(p, *, date=None, title=None, industry=None):
    """ZIP project caption: square black mono box, date on top, TITLE · INDUSTRY below.
    Decorative (aria-hidden): the same facts are in the card text / link name."""
    d = E(date if date is not None else p['date'])
    t = title if title is not None else p['title']
    i = industry if industry is not None else p['industry']
    ind = (f'<span class="wk-cap__dot">·</span><span class="wk-cap__ind">{roll(i)}</span>') if i else ''
    return (f'<span class="wk-cap" aria-hidden="true"><span class="wk-cap__date">{d}</span>'
            f'<span class="wk-cap__line"><span class="wk-cap__title">{roll(t)}</span>{ind}</span></span>')


def tile(ctx, p, *, sizes, eager=False, cls='', focusable=False):
    """Project tile (link with View Project cursor, or a plain block when the project has no
    destination). focusable=False keeps it out of the tab order when a text link next to it
    already leads to the same place (the card's own link then drives the hover state). Such a
    duplicate is also hidden from assistive tech, so screen-reader link lists name each project
    once (by the card's own link) instead of twice."""
    extra = '' if focusable or not lib.project_href(ctx, p) else 'tabindex="-1" aria-hidden="true"'
    open_, close = lib.project_tag(ctx, p, ('wk-tile ' + cls).strip(), extra=extra)
    img = lib.picture(ctx, p['cover'], f"{p['title']} — {p['industry']} project artwork", sizes=sizes, eager=eager)
    return (f'{open_}<span class="wk-tile__media reveal-image" style="aspect-ratio:{lib.ratio(p["cover"])}">{img}</span>'
            f'{caption(p)}{close}')


def card_link(ctx, p):
    """Doc card template call to action: case study page, live site, or nothing."""
    if p['kind'] == 'case':
        return (f'<a class="wk-link" href="{ctx.url(p["route"])}" aria-label="{E(W["card_cta"])}: {E(p["title"])}">'
                f'<span class="wk-link__label">{E(W["card_cta"])}</span>'
                f'<span class="wk-link__icon" aria-hidden="true">{ICONS["arrow-r"]}</span></a>')
    if p['kind'] == 'external':
        return (f'<a class="wk-link wk-link--ext" href="{E(p["url"])}" target="_blank" rel="noopener" '
                f'aria-label="Visit Site: {E(p["title"])} (opens in a new tab)">'
                f'<span class="wk-link__label">Visit Site</span>'
                f'<span class="wk-link__icon" aria-hidden="true">{ICONS["arrow-ne"]}</span></a>')
    if p['date'].strip().upper() == 'COMING SOON':
        return '<span class="wk-soon"><i aria-hidden="true"></i>Coming soon</span>'
    return ''


def card(ctx, p, n, size):
    slug = E(p['slug'])
    meta = [f'<p class="wk-meta"><span class="wk-meta__k">Industry:</span> {E(p["industry"])}</p>']
    svc = services(p)
    if svc:
        # each service stays on one line with its trailing separator; lines break between services
        items = ' '.join(f'<span class="wk-meta__item">{E(s)}{"&nbsp;·" if i < len(svc) - 1 else ""}</span>'
                         for i, s in enumerate(svc))
        meta.append(f'<p class="wk-meta"><span class="wk-meta__k">What we created:</span> {items}</p>')
    # The date is printed in the tile's caption box (ZIP label, decorative for AT); repeating it in
    # the info row put the same fact twice within 40 px, so here it is only announced.
    if p['date'].strip().upper() != 'COMING SOON':
        meta.append(f'<p class="sr-only">Date: {E(p["date"])}</p>')
    link = card_link(ctx, p)
    # Info grid: index · title · call to action on one baseline, the doc's card lines below the title.
    return f'''<article class="wk-card wk-card--{size}" style="--a:{_aspect(p['cover']):.4f}" aria-labelledby="wk-t-{slug}">
  {tile(ctx, p, sizes=SIZES_FULL if size == 'full' else SIZES_HALF)}
  <div class="wk-info" data-reveal style="--y:24px;--d:120ms">
    <span class="wk-info__n" aria-hidden="true">{n:02d}</span>
    <h3 class="wk-info__title" id="wk-t-{slug}">{E(p['title'])}</h3>
    <div class="wk-info__meta">{''.join(meta)}</div>
    {f'<div class="wk-info__cta">{link}</div>' if link else ''}
  </div>
</article>'''


def rows(items, pattern=(1, 2, 2)):
    """Editorial rhythm: one full-width row, then two pairs, repeated (10 projects -> 1 2 2 1 2 2).
    Pairs size their tiles by aspect ratio (CSS) so both images keep their native ratio at equal height."""
    out, i, k = [], 0, 0
    while i < len(items):
        n = min(pattern[k % len(pattern)], len(items) - i)
        out.append(items[i:i + n]); i += n; k += 1
    return out


def hero(ctx):
    first, second = [fmt(t) for t in W['hero']['title']]
    names = ''.join(f'<li>{E(p["title"])}</li>' for p in P.PROJECTS)
    ctas = (button(ctx, content.PRIMARY_CTA, ctx.url('contact'), variant='dark', lead=lead_mark(ctx))
            + button(ctx, 'See the projects', ctx.url('work', 'projects'), variant='light'))
    return f'''<section class="wk-hero" aria-labelledby="wk-hero-title">
  <div class="container wk-hero__inner">
    <div class="wk-hero__lockup">
      {pill_label('The Work')}
      <h1 class="wk-hero__title" id="wk-hero-title" data-reveal style="--y:80px;--d:200ms"><span>{E(first)}</span> <span class="wk-hero__second">{E(second)}</span></h1>
      <p class="wk-hero__sub" data-reveal style="--y:80px;--d:300ms">{E(fmt(W['hero']['body']))}</p>
    </div>
    <div class="wk-hero__ctas" data-reveal style="--y:60px;--d:400ms">{ctas}</div>
  </div>
  <div class="container wk-hero__band" data-reveal="fade" style="--d:600ms">
    <div class="wk-marquee" data-ticker data-direction="left" data-speed="25" aria-hidden="true">
      <ul class="wk-marquee__list" data-ticker-list role="list">{names}</ul>
    </div>
  </div>
</section>'''


def intro(ctx):
    it = W['intro']
    lines = ''.join(f'<li class="wk-intro__row" data-reveal><span class="wk-intro__n" aria-hidden="true">{i:02d}</span>'
                    f'<span class="wk-intro__text">{E(fmt(t))}</span></li>' for i, t in enumerate(it['lines'], 1))
    return f'''<section class="wk-intro section" aria-labelledby="wk-intro-title">
  <div class="container wk-intro__grid">
    <h2 class="wk-intro__title" id="wk-intro-title" data-split>{E(fmt(it['title']))}</h2>
    <div class="wk-intro__body">
      <ol class="wk-intro__list" role="list" data-stagger="140">{lines}</ol>
      <p class="wk-intro__closing" data-reveal style="--d:640ms"><i aria-hidden="true"></i>{E(fmt(it['closing']))}</p>
    </div>
  </div>
</section>'''


def grid(ctx):
    n, html = 0, []
    for row in rows(P.PROJECTS):
        size = 'full' if len(row) == 1 else 'half'
        cards = []
        for p in row:
            n += 1
            cards.append(card(ctx, p, n, size))
        html.append(f'<div class="wk-row wk-row--{"full" if size == "full" else "pair"}">{"".join(cards)}</div>')
    cases = len(P.CASES)
    return f'''<section class="wk-projects section" id="projects" aria-labelledby="wk-projects-title">
  <div class="container">
    <div class="wk-index" data-reveal="fade">
      <h2 class="wk-index__title" id="wk-projects-title">All projects</h2>
      <span class="wk-index__count">{len(P.PROJECTS):02d} projects <span aria-hidden="true">·</span> {cases:02d} case studies</span>
    </div>
    <div class="wk-grid">{''.join(html)}</div>
  </div>
</section>'''


def story(ctx):
    """The document's CASE STUDY STRUCTURE (label used as the heading; no invented headline)."""
    items = ''.join(
        f'<li class="card wk-story__card" data-reveal><span class="dots" aria-hidden="true"><i></i><i></i><i></i><i></i></span>'
        f'<div class="wk-story__copy"><h3 class="wk-story__name">{E(name)}</h3><p class="wk-story__q">{E(q)}</p></div>'
        f'<span class="wk-story__n" aria-hidden="true">{i:02d}</span></li>'
        for i, (name, q) in enumerate(W['case_structure'], 1))
    return f'''<section class="wk-story section" aria-labelledby="wk-story-title">
  <div class="container">
    <header class="section-head section-head--center wk-story__head">
      {pill_label('Case Studies')}
      <h2 class="section-head__title" id="wk-story-title" data-split>Case study structure</h2>
    </header>
    <div class="frame wk-story__frame">
      <ol class="wk-story__list" role="list" data-stagger="90">{items}</ol>
    </div>
  </div>
</section>'''


def slot(ctx):
    c = W['cta']
    handles = ''.join(f'<i class="wk-slot__h wk-slot__h--{k}" aria-hidden="true"></i>' for k in ('tl', 'tr', 'bl', 'br'))
    return f'''<section class="wk-cta section" aria-labelledby="wk-cta-title">
  <div class="container">
    <div class="wk-slot" data-reveal="scale">
      {handles}
      <svg class="wk-slot__x" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true" focusable="false"><path d="M0 0 100 100M100 0 0 100" fill="none" stroke="currentColor" stroke-width="1" vector-effect="non-scaling-stroke"/></svg>
      <div class="wk-slot__inner">
        <span class="wk-slot__n" aria-hidden="true">{len(P.PROJECTS) + 1:02d}</span>
        <h2 class="wk-slot__title" id="wk-cta-title" data-split>{E(fmt(c['title']))}</h2>
        <p class="wk-slot__body" data-reveal style="--d:160ms">{E(fmt(c['body']))}</p>
        <div data-reveal style="--y:60px;--d:260ms">{button(ctx, c['cta'], ctx.url('contact'), variant='dark', lead=lead_mark(ctx))}</div>
      </div>
      {caption(None, date='Next', title='Your project', industry='')}
    </div>
  </div>
</section>'''


def render(ctx):
    return hero(ctx) + intro(ctx) + grid(ctx) + story(ctx) + slot(ctx)
