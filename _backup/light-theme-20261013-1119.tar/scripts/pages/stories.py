"""CLIENT STORIES page (/client-stories/).

  hero        pill · H1 (STORIES.hero.title, two balanced sentences) · sub
  stories     ONLY when content.STORIES['testimonials'] is non-empty: the home "believe" coverflow
              carousel with real testimonial cards (quote, name, role — company, stars if supplied).
              The content document only has placeholders, so nothing is rendered today.
  experience  pill · H2 · body · the five collaboration lines as a staggered row of numbered
              cards (reference frame + price-card vocabulary) · the two closing lines emphasised
  review      reference wide card in the grey frame: title, body, black "Leave a Review" button
              (mailto CONFIG.email with a prefilled subject)
CSS: src/css/34-stories.css (.sto-*). Shared look: .frame/.card/.dots (02-components), page hero
(.pg-hero, pages/who.py), carousel/card (23-believe.css), button/link (24-agency.css).
"""
from urllib.parse import quote

import lib
from lib import E, fmt, CONFIG, BRAND, pill_label
from content import STORIES
from pages.who import page_hero
from sections.home_believe import carousel, card
from sections.home_agency import dark_button, T

DOTS = '<span class="dots" aria-hidden="true"><i></i><i></i><i></i><i></i></span>'


# ------------------------------------------------------------------ testimonials (generic)
def _norm(t):
    """Accept (quote, name, role, company[, stars]) tuples or dicts with the same keys."""
    if isinstance(t, dict):
        return {k: t.get(k) for k in ('quote', 'name', 'role', 'company', 'stars', 'avatar', 'highlights', 'stats')}
    keys = ('quote', 'name', 'role', 'company', 'stars')
    d = dict(zip(keys, t))
    return {k: d.get(k) for k in ('quote', 'name', 'role', 'company', 'stars', 'avatar', 'highlights', 'stats')}


def _initials(name):
    parts = [p for p in (name or '').replace('.', ' ').split() if p[:1].isalpha()]
    return ''.join(p[0] for p in parts[:2]).upper() or '·'


def _testimonial_card(ctx, t):
    quote_html = E(fmt(t['quote'] or ''))
    for ph in t.get('highlights') or []:
        quote_html = quote_html.replace(E(ph), f'<strong>{E(ph)}</strong>', 1)
    quote_html = f'<blockquote class="bel-card__bq"><p>&ldquo;{quote_html}&rdquo;</p></blockquote>'
    role = ' — '.join(x for x in (t.get('role'), t.get('company')) if x)
    if t.get('avatar'):
        av = f'<span class="bel-card__photo">{lib.img(ctx, t["avatar"], "", w=44, h=44)}</span>'
    else:
        av = f'<span class="bel-card__initials" aria-hidden="true">{E(_initials(t["name"]))}</span>'
    tiles = ''
    if t.get('stats'):
        from sections.home_believe import tile
        tiles = ''.join(tile(v, l) for v, l in t['stats'])
    return card(quote_html=quote_html, name=E(t['name'] or ''), role=E(role), avatar_html=av,
                tiles_html=tiles, stars=t.get('stars') or 0, single=len(t.get('stats') or []) == 1)


def _testimonials(ctx):
    items = [_norm(t) for t in STORIES.get('testimonials') or []]
    items = [t for t in items if t.get('quote') and t.get('name')]
    if not items:
        return ''
    slides = [_testimonial_card(ctx, t) for t in items]
    return f'''<section class="section sto-stories" id="stories" aria-labelledby="stories-title">
  <div class="container sto-stories__inner">
    <h2 class="sr-only" id="stories-title">Client Stories</h2>
    {carousel(slides, label='Client stories', cid='sto', cls='sto-car')}
  </div>
</section>'''


# ------------------------------------------------------------------ sections
def _hero(ctx):
    h = STORIES['hero']
    title = ''.join(f'<span class="sto-hero__line">{E(T(line))}</span> ' for line in h['title']).strip()
    return page_hero(ctx, 'Client Stories', title, sub_html=E(T(h['body'])), cls='sto-hero')


def _experience(ctx):
    x = STORIES['experience']
    n = len(x['lines'])
    steps = []
    for i, line in enumerate(x['lines'], 1):
        last = i == n
        steps.append(f'''<li class="card sto-step{" sto-step--last" if last else ""}" data-reveal style="--y:48px">
          {DOTS}
          <span class="sto-step__top" aria-hidden="true"><span class="sto-step__n mono">{i:02d}<span>/{n:02d}</span></span><span class="sto-step__pip" aria-hidden="true"></span></span>
          <span class="sto-step__t">{E(T(line))}</span>
        </li>''')
    c1, c2 = (x['closing'] + ['', ''])[:2]
    mark = lib.img(ctx, 'assets/brand/logo-mark-3d.webp', '', w=64, h=64, cls='sto-close__img')
    return f'''<section class="section sto-exp" id="experience" aria-labelledby="experience-title">
  <div class="container sto-exp__inner">
    <header class="section-head sto-head">
      {pill_label(x['label'])}
      <h2 class="section-head__title" id="experience-title" data-split>{E(T(x['title']))}</h2>
      <p class="section-head__sub" data-reveal style="--d:160ms">{E(T(x['body']))}</p>
    </header>
    <div class="frame sto-frame">
      <ol class="sto-steps" role="list" data-stagger="90">{''.join(steps)}</ol>
      <div class="card sto-close" data-reveal style="--y:48px;--d:200ms">
        {DOTS}
        <span class="sto-close__mark">{mark}</span>
        <p class="sto-close__text"><span class="sto-close__a">{E(T(c1))}</span> <span class="sto-close__b">{E(T(c2))}</span></p>
      </div>
    </div>
  </div>
</section>'''


def _review(ctx):
    r = STORIES['review_cta']
    email = CONFIG.get('email') or ''
    href = f'mailto:{email}?subject={quote("Review for " + BRAND)}' if email else ctx.url('contact')
    btn = dark_button(f"{r['cta']}", 'Send an email', href, icon_name='arrow-r', cls='sto-review__btn',
                      label=f"{r['cta']} (opens your email app)" if email else r['cta'])
    note = f'<p class="sto-review__mail mono">{E(email)}</p>' if email and not CONFIG.get('email_is_placeholder') else ''
    return f'''<section class="section sto-review" id="review" aria-labelledby="review-title">
  <div class="container sto-review__inner">
    <div class="frame sto-review__frame" data-reveal style="--y:60px">
      <div class="card sto-review__card">
        {DOTS}
        <div class="sto-review__main">
          <span class="sto-review__icon" aria-hidden="true">{lib.svg_inline('assets/brand/logo-mark.svg')}</span>
          <div class="sto-review__copy">
            <h2 class="sto-review__title" id="review-title">{E(T(r['title']))}</h2>
            <p class="sto-review__body">{E(T(r['body']))}</p>
          </div>
        </div>
        <div class="sto-review__cta">{btn}{note}</div>
      </div>
    </div>
  </div>
</section>'''


def render(ctx):
    return _hero(ctx) + _testimonials(ctx) + _experience(ctx) + _review(ctx)
