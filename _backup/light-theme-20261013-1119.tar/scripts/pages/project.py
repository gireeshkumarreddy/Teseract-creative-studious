"""Case-study page (/projects/<slug>/) — ZIP case page rhythm.

Header (back link, H1, date · industry, "What we created" chips) -> 13-image gallery in the
ZIP half/full rhythm (indices {0,1,3,4,7,8} half-width, native aspect, .reveal-image) ->
next case study (wrapping) with its cover tile + Start a Project.
No Challenge/Idea/Experience/Details/Result headings: the document supplies no narrative.
"""
import lib
from lib import E, fmt, ICONS, roll, button, chip
import content
import projects as P
from pages.work import tile, lead_mark, services

W = content.WORK
HALF = {0, 1, 3, 4, 7, 8}

# Gallery runs edge to edge with 12 px gutters (8 px on phone), capped at 1920 px of imagery.
SIZES = {
    'full': '(min-width:1944px) 1920px, (min-width:800px) calc(100vw - 24px), calc(100vw - 16px)',
    'half': '(min-width:1944px) 954px, (min-width:800px) calc(50vw - 18px), calc(50vw - 12px)',
}
# Next-project tile: 7/12 of the 1344 px container on desktop, full container width below.
SIZES_NEXT = '(min-width:1440px) 756px, (min-width:800px) calc(100vw - 80px), calc(100vw - 32px)'


def _alt(p, i, total):
    if i == 0:
        return f"{p['title']} — brand typography board"
    if i == 1:
        return f"{p['title']} — brand colour palette board"
    return f"{p['title']} — project visual {i + 1} of {total}"


def head(ctx, p, idx):
    chips = ''.join(chip(s) for s in services(p))
    created = (f'''<div class="pj-head__services" data-reveal style="--y:40px;--d:400ms">
        <p class="pj-head__label" id="pj-created">What we created</p>
        <ul class="chips pj-head__chips" role="list" aria-labelledby="pj-created">{chips}</ul>
      </div>''' if chips else '')
    back = (f'<a class="pj-back" href="{ctx.url("work")}" aria-label="Back to all work">'
            f'<span class="pj-back__icon" aria-hidden="true">{ICONS["arrow-r"]}</span>{roll("All work")}</a>')
    return f'''<section class="pj-head" aria-labelledby="pj-title">
  <div class="container">
    <nav class="pj-head__bar" aria-label="Case study" data-reveal="fade">
      {back}
      <span class="pj-head__count">Case study {idx + 1:02d} / {len(P.CASES):02d}</span>
    </nav>
    <div class="pj-head__grid">
      <div class="pj-head__main">
        <h1 class="pj-head__title" id="pj-title" data-reveal style="--y:80px;--d:200ms">{E(p['title'])}</h1>
        <p class="pj-head__meta" data-reveal style="--y:40px;--d:300ms"><span>{E(p['date'])}</span><span class="pj-head__dot" aria-hidden="true">·</span><span>{E(p['industry'])}</span></p>
      </div>
      {created}
    </div>
  </div>
</section>'''


def gallery(ctx, p):
    imgs = p['images']
    frames = []
    for i, name in enumerate(imgs):
        slot = 'half' if i in HALF else 'full'
        img = lib.picture(ctx, name, _alt(p, i, len(imgs)), sizes=SIZES[slot], eager=i < 2)
        frames.append(f'<figure class="pj-frame pj-frame--{slot} reveal-image" style="aspect-ratio:{lib.ratio(name)}">{img}</figure>')
    return (f'<section class="pj-gallery-wrap" aria-label="{E(p["title"])} project gallery">'
            f'<div class="pj-gallery">{"".join(frames)}</div></section>')


def next_block(ctx, p, idx):
    nxt = P.CASES[(idx + 1) % len(P.CASES)]
    k = (idx + 1) % len(P.CASES) + 1
    c = W['cta']
    btns = (button(ctx, c['cta'], ctx.url('contact'), variant='dark', lead=lead_mark(ctx))
            + button(ctx, 'All work', ctx.url('work'), variant='light'))
    return f'''<section class="pj-next section" aria-labelledby="pj-next-title">
  <div class="container pj-next__grid">
    <div class="pj-next__head">
      <p class="pj-next__label" data-reveal>Next project <span aria-hidden="true">—</span> {k:02d} / {len(P.CASES):02d}</p>
      <h2 class="pj-next__title" id="pj-next-title" data-reveal style="--y:60px;--d:100ms"><a href="{ctx.url(nxt['route'])}" aria-label="Next project: {E(nxt['title'])}, {E(nxt['industry'])}" data-letter-roll>{roll(nxt['title'])}</a></h2>
    </div>
    <div class="pj-next__media">{tile(ctx, nxt, sizes=SIZES_NEXT, cls='pj-next__tile')}</div>
    <div class="pj-next__cta" data-reveal style="--d:260ms">
      <p class="pj-next__line"><strong>{E(fmt(c['title']))}</strong> {E(fmt(c['body']))}</p>
      <div class="pj-next__btns">{btns}</div>
    </div>
  </div>
</section>'''


def render(ctx, p):
    idx = next(i for i, c in enumerate(P.CASES) if c['slug'] == p['slug'])
    return head(ctx, p, idx) + gallery(ctx, p) + next_block(ctx, p, idx)
