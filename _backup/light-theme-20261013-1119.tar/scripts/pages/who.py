"""WHO WE ARE page (/who-we-are/).

Also hosts the small inner-page building blocks reused by pages/contact.py and pages/legal.py
(page hero, section head with an id, corner dots, reference checklist seal) so the three
"pages" routes share one vocabulary. CSS: src/css/30-who.css (.pg-* shared, .who-* page).
"""
from lib import E, fmt, img, svg_inline, pill_label
from content import WHO, BRAND as BRAND_COPY

# Reference checklist seal-check (ref-plans-faq-footer, appendix A), 20x29.
SEAL = ('<svg class="seal" viewBox="0 0 20 29" width="20" height="29" aria-hidden="true" focusable="false">'
        '<path d="M15.4448 8.01492C15.6348 8.47431 15.9994 8.83947 16.4585 9.03011L18.0683 9.69694C18.5278 9.88724 18.8928 10.2523 19.0831 10.7117C19.2734 11.1711 19.2734 11.6873 19.0831 12.1467L18.4167 13.7554C18.2263 14.2151 18.2261 14.7318 18.4173 15.1912L19.0825 16.7994C19.1769 17.027 19.2254 17.2709 19.2255 17.5172C19.2255 17.7636 19.177 18.0075 19.0827 18.2351C18.9885 18.4626 18.8503 18.6694 18.6761 18.8436C18.5019 19.0177 18.2951 19.1558 18.0674 19.25L16.4587 19.9164C15.9994 20.1063 15.6342 20.4709 15.4436 20.93L14.7767 22.5399C14.5864 22.9993 14.2214 23.3644 13.762 23.5547C13.3026 23.745 12.7863 23.745 12.3269 23.5547L10.7182 22.8883C10.2588 22.6985 9.74276 22.6989 9.2836 22.8894L7.67374 23.5553C7.21457 23.7451 6.69881 23.745 6.23976 23.5548C5.7807 23.3647 5.41589 23.0001 5.22546 22.5411L4.55844 20.9308C4.36848 20.4714 4.00388 20.1063 3.54477 19.9156L1.93491 19.2488C1.47568 19.0586 1.11078 18.6938 0.920407 18.2346C0.730035 17.7755 0.729777 17.2595 0.919689 16.8001L1.58604 15.1914C1.77587 14.732 1.77548 14.216 1.58496 13.7568L0.919567 12.1458C0.825228 11.9183 0.776651 11.6743 0.776611 11.428C0.776572 11.1817 0.825071 10.9378 0.919337 10.7102C1.0136 10.4826 1.15179 10.2758 1.326 10.1017C1.50021 9.92752 1.70703 9.7894 1.93463 9.69521L3.54334 9.02886C4.00233 8.83908 4.36727 8.47493 4.55805 8.01635L5.22488 6.40649C5.41518 5.94706 5.78019 5.58205 6.23962 5.39175C6.69905 5.20145 7.21526 5.20145 7.67468 5.39175L9.28339 6.0581C9.74283 6.24793 10.2589 6.24754 10.718 6.05702L12.3285 5.39278C12.7879 5.20259 13.304 5.20263 13.7633 5.39289C14.2227 5.58315 14.5876 5.94806 14.778 6.40737L15.445 8.01771L15.4448 8.01492Z" fill="#C2C2C2"/>'
        '<path fill-rule="evenodd" clip-rule="evenodd" d="M13.9166 11.8509C14.0502 11.6411 14.0949 11.3867 14.041 11.1439C13.9871 10.901 13.8389 10.6895 13.6291 10.5559C13.4192 10.4223 13.1649 10.3776 12.922 10.4315C12.6792 10.4854 12.4677 10.6336 12.3341 10.8434L8.66283 16.6122L6.98283 14.5122C6.82751 14.3179 6.60138 14.1933 6.35418 14.1658C6.10699 14.1382 5.85897 14.21 5.6647 14.3653C5.47043 14.5206 5.34582 14.7468 5.31827 14.9939C5.29073 15.2411 5.36251 15.4892 5.51783 15.6834L8.01783 18.8084C8.111 18.925 8.23066 19.0177 8.36687 19.0788C8.50308 19.1398 8.65189 19.1674 8.80093 19.1594C8.94998 19.1513 9.09494 19.1077 9.22376 19.0324C9.35258 18.957 9.46154 18.8519 9.54158 18.7259L13.9166 11.8509Z" fill="#161616"/></svg>')

DOTS = '<span class="dots" aria-hidden="true"><i></i><i></i><i></i><i></i></span>'

# Small white glyphs for the "How we think" icon tiles (drawn for this page).
GLYPHS = {
    'people': '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="12" cy="8.2" r="3.6" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M4.8 19.6c.9-3.6 3.7-5.6 7.2-5.6s6.3 2 7.2 5.6" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>',
    'detail': '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="2.4" fill="currentColor"/><path d="M12 3.5v4M12 16.5v4M3.5 12h4M16.5 12h4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/><path d="M5 8V5h3M16 5h3v3M19 16v3h-3M8 19H5v-3" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" opacity=".55"/></svg>',
}


def mark3d(ctx, cls, size, alt='', eager=False):
    return img(ctx, 'assets/brand/logo-mark-3d.webp', alt, w=size, h=round(size * 519 / 515), cls=cls, eager=eager)


def flat_mark(cls='pg-mark'):
    return f'<span class="{cls}" aria-hidden="true">{svg_inline("assets/brand/logo-mark.svg")}</span>'


def page_hero(ctx, label, title_html, *, sub_html='', extra='', cls=''):
    """Inner-page hero in the reference vocabulary: pill label, 72px H1, 18px balanced sub.
    Appear timings follow the reference hero (H1 y80 @200ms, sub y80 @300ms, extras @400ms+)."""
    sub = f'<p class="pg-hero__sub" data-reveal style="--y:80px;--d:300ms">{sub_html}</p>' if sub_html else ''
    return (f'<section class="pg-hero{(" " + cls) if cls else ""}" aria-labelledby="page-title">'
            f'<div class="container"><div class="pg-hero__inner">{pill_label(label)}'
            f'<h1 class="pg-hero__title" id="page-title" data-reveal style="--y:80px;--d:200ms">{title_html}</h1>'
            f'{sub}{extra}</div></div></section>')


def head(label, title_html, hid, *, sub_html=None, tag='h2', align='center', visible_title=True):
    """lib.section_head markup plus an id on the heading (for aria-labelledby)."""
    lab = pill_label(label) if label else ''
    sub = f'<p class="section-head__sub" data-reveal style="--d:160ms">{sub_html}</p>' if sub_html else ''
    if not visible_title:
        return f'<header class="section-head section-head--{align}">{lab}<{tag} class="sr-only" id="{hid}">{title_html}</{tag}></header>'
    return (f'<header class="section-head section-head--{align}">{lab}'
            f'<{tag} class="section-head__title" id="{hid}" data-split>{title_html}</{tag}>{sub}</header>')


# ------------------------------------------------------------------ sections
def _hero(ctx):
    h = WHO['hero']
    first = E(fmt(h['body'][0])).replace(E(fmt('{brand}')), f'<strong>{E(fmt("{brand}"))}</strong>', 1)
    sub = ' '.join([first] + [E(fmt(t)) for t in h['body'][1:]])
    words = ''.join(f'<li class="who-marquee__item">{flat_mark("who-marquee__mark")}<span>{E(w)}</span></li>'
                    for w in BRAND_COPY['personality'])
    marquee = (f'<div class="who-marquee" data-reveal="fade" style="--d:600ms">'
               f'<div class="who-marquee__track" data-ticker data-direction="left" data-speed="25">'
               f'<ul class="who-marquee__list" data-ticker-list role="list" aria-label="Brand personality">{words}</ul>'
               f'</div></div>')
    return page_hero(ctx, 'Who We Are', E(WHO['hero']['title']), sub_html=sub, extra=marquee, cls='who-hero')


def _why(ctx):
    w = WHO['why']
    q = w['question']
    head_q, sep, tail = q.rpartition(' that ')
    q_html = f'{E(head_q)} that <span>{E(tail)}</span>' if sep else E(q)
    return f'''<section class="section who-sec who-why" id="why" aria-labelledby="why-title">
  <div class="container who-sec__inner">
    {head(w['label'], E(w['title']), 'why-title')}
    <div class="frame who-frame" data-reveal style="--y:60px">
      <article class="card who-why__card" aria-label="{E(w['label'])}">
        {DOTS}
        <div class="who-why__col who-why__col--q">
          <span class="who-why__icon">{mark3d(ctx, 'who-why__mark', 48)}</span>
          <p class="who-why__q">{q_html}</p>
        </div>
        <div class="who-why__col who-why__col--a">
          <p class="who-why__a">{E(w['answer'])}</p>
          <p class="who-why__body">{E(w['body'])}</p>
          <p class="who-why__close">{flat_mark('who-why__tile')}<span>{E(w['closing'])}</span></p>
        </div>
      </article>
    </div>
  </div>
</section>'''


def _philosophy(ctx):
    p = WHO['philosophy']
    n = len(p['steps'])
    items = []
    for i, step in enumerate(p['steps'], 1):
        lead, _, rest = step.partition(' ')
        bars = ''.join(f'<i{" class=on" if k < i else ""}></i>' for k in range(n))
        items.append(f'''<li class="card who-step" data-reveal style="--y:60px">
          {DOTS}
          <div class="who-step__top">
            <span class="who-step__n mono">{i:02d}<span class="who-step__of">/{n:02d}</span></span>
            <span class="who-step__bar" aria-hidden="true">{bars}</span>
          </div>
          <p class="who-step__t"><span class="who-step__lead">{E(lead)}</span> {E(rest)}</p>
        </li>''')
    return f'''<section class="section who-sec who-phil" id="philosophy" aria-labelledby="philosophy-title">
  <div class="container who-sec__inner">
    {head(p['label'], E(p['title']), 'philosophy-title', sub_html=E(p['body']))}
    <div class="frame who-frame">
      <ol class="who-steps" role="list" data-stagger="110">{''.join(items)}</ol>
    </div>
  </div>
</section>'''


def _think(ctx):
    t = WHO['think']
    icons = [f'<span class="who-tile">{GLYPHS["people"]}</span>',
             f'<span class="who-tile">{GLYPHS["detail"]}</span>',
             f'<span class="who-tile">{svg_inline("assets/brand/logo-mark.svg")}</span>']
    cards = []
    for i, (title, l1, l2) in enumerate(t['items']):
        cards.append(f'''<article class="card who-think__card" data-reveal style="--y:60px" aria-labelledby="think-{i + 1}">
          {DOTS}
          <div class="who-think__top">{icons[i % len(icons)]}<span class="who-think__n mono" aria-hidden="true">{i + 1:02d}</span></div>
          <h3 class="who-think__t" id="think-{i + 1}">{E(title)}</h3>
          <p class="who-think__l1">{E(l1)}</p>
          <p class="who-think__l2">{E(l2)}</p>
        </article>''')
    return f'''<section class="section who-sec who-think" id="how-we-think" aria-labelledby="think-title">
  <div class="container who-sec__inner">
    {head(t['label'], E(t['label']), 'think-title', visible_title=False)}
    <div class="frame who-frame who-frame--wide">
      <div class="who-think__grid" data-stagger="110">{''.join(cards)}</div>
    </div>
  </div>
</section>'''


def _promise(ctx):
    p = WHO['promise']
    lines = ''.join(f'<li data-reveal style="--y:24px">{E(l)}</li>' for l in p['lines'])
    underline = ('<svg class="who-promise__line" viewBox="0 0 420 24" preserveAspectRatio="none" aria-hidden="true" focusable="false">'
                 '<path d="M5 15.5C70 8.5 170 5.5 262 7.2c55 1 104 4.2 153 9.3" pathLength="1"/></svg>')
    return f'''<section class="who-promise" id="promise" aria-labelledby="promise-title">
  <div class="who-promise__panel">
    <div class="container who-promise__inner">
      <span class="who-promise__mark" data-reveal="scale">{mark3d(ctx, 'who-promise__img', 112)}</span>
      {pill_label(p['label'])}
      <h2 class="who-promise__title" id="promise-title" data-split>{E(p['title'])}</h2>
      <ul class="who-promise__lines" role="list" data-stagger="90" data-stagger-base="120">{lines}</ul>
      <p class="who-promise__q" data-reveal style="--y:40px;--d:420ms"><em>{E(p['question'])}</em>{underline}</p>
    </div>
  </div>
</section>'''


def render(ctx):
    return _hero(ctx) + _why(ctx) + _philosophy(ctx) + _think(ctx) + _promise(ctx)
