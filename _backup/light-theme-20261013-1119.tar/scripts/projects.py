"""Portfolio data carried over from the supplied ZIP project (scripts/build.py PROJECTS
and scripts/page-assets.json). Names, dates, industries and services are preserved as
supplied; only the stray "MAR . 2025" date punctuation is normalised.

kind:
  'case'     -> has a 13-image case study page at projects/<slug>/
  'external' -> links to the live client site (opens in a new tab)
  'static'   -> no destination supplied (shown without a link)
"""
import json, pathlib

ROOT = pathlib.Path(__file__).resolve().parents[1]
_PAGE_ASSETS = json.loads((ROOT / 'scripts/page-assets.json').read_text())

PROJECTS = [
    {'slug': 'two26-studio', 'title': 'Two26 Studio', 'date': 'SEP 2026', 'industry': 'Design Agency',
     'kind': 'external', 'url': 'https://two26.studio/', 'services': None, 'cover': 'home-01'},
    {'slug': 'evermark-global', 'title': 'Evermark Global', 'date': 'AUG 2026', 'industry': 'Logistics',
     'kind': 'external', 'url': 'https://www.evermark-global.com/', 'services': None, 'cover': 'home-02'},
    {'slug': 'risen-social', 'title': 'Risen Social', 'date': 'MAR 2026', 'industry': 'Media Agency',
     'kind': 'external', 'url': 'https://www.risensocial.com/', 'services': None, 'cover': 'home-03'},
    {'slug': 'hocl-labs', 'title': 'HOCL LABS', 'date': 'JULY 2025', 'industry': 'Luxury Skincare',
     'kind': 'case', 'url': None, 'services': 'UI/UX Design / Brand Strategy / Development', 'cover': 'home-04'},
    {'slug': 'taurus-arena', 'title': 'Taurus Arena', 'date': 'MAY 2026', 'industry': 'Trading Prop Firm',
     'kind': 'case', 'url': None, 'services': 'Website Design / UI UX / Motion Design / Brand Refinement', 'cover': 'home-05'},
    {'slug': 'fragile-base', 'title': 'FRAGILE BASE', 'date': 'MAR 2025', 'industry': 'Clothing Brand',
     'kind': 'case', 'url': None, 'services': 'Brand Direction / Web Design / Shopify Development', 'cover': 'home-06'},
    {'slug': 'aesthetic-origins', 'title': 'Aesthetic Origins', 'date': 'APRIL 2025', 'industry': 'Health Care',
     'kind': 'case', 'url': None, 'services': 'Personal Branding / Web Design / Business Strategy', 'cover': 'home-07'},
    {'slug': 'tafuta', 'title': 'Tafuta', 'date': 'MAR 2024', 'industry': 'Event Finder App',
     'kind': 'case', 'url': None, 'services': 'Branding / App Design', 'cover': 'home-08'},
    {'slug': 'sunnakids', 'title': 'SunnaKids', 'date': 'FEB 2025', 'industry': 'App Design',
     'kind': 'static', 'url': None, 'services': None, 'cover': 'home-09'},
    {'slug': 'real-estate', 'title': 'Web Design', 'date': 'COMING SOON', 'industry': 'Real Estate',
     'kind': 'static', 'url': None, 'services': None, 'cover': 'home-10'},
]

for p in PROJECTS:
    key = f"projects__{p['slug']}"
    p['images'] = _PAGE_ASSETS.get(key, []) if p['kind'] == 'case' else []
    p['route'] = f"projects/{p['slug']}" if p['kind'] == 'case' else None
    p['services_list'] = [s.strip() for s in p['services'].split(' / ')] if p['services'] else []

CASES = [p for p in PROJECTS if p['kind'] == 'case']


def by_slug(slug):
    return next(p for p in PROJECTS if p['slug'] == slug)
