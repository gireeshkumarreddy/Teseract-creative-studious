"""Page shell: <head>, floating pill header, menu overlay slot, footer slot, page shade."""
import importlib, sys, traceback
import lib
from lib import E, fmt, CONFIG, BRAND, button, roll, icon, ICONS

QUICK_LINKS = [('work', 'The Work'), ('what-we-create', 'What We Create'), ('our-approach', 'Our Approach'), ('client-stories', 'Client Stories')]


def _safe(module, func, *args, **kw):
    try:
        return getattr(importlib.import_module(module), func)(*args, **kw)
    except Exception:
        tb = traceback.format_exc()
        print(f'!! {module}.{func} failed\n{tb}', file=sys.stderr)
        lib.FAILURES.append((module, func, tb))
        return f'<div class="build-error"><pre>{E(module)}.{E(func)} failed:\n{E(tb[-900:])}</pre></div>'


def wordmark(ctx, cls='wordmark'):
    return lib.svg_inline('assets/brand/wordmark.svg', cls)


def header(ctx):
    current = ctx.route.split('/')[0]
    section = 'work' if current == 'projects' else current      # case studies belong to The Work

    def cur(r):
        if r == ctx.route:
            return ' aria-current="page"'
        return ' aria-current="true"' if r == section else ''
    links = ''.join(
        f'<li><a class="nav-link" href="{ctx.url(r)}" aria-label="{E(t)}"{cur(r)}>{roll(t)}</a></li>'
        for r, t in QUICK_LINKS)
    return f'''<header class="site-header" data-header>
  <nav class="nav-pill" aria-label="Primary">
    <a class="nav-brand" href="{ctx.url('')}" aria-label="{E(BRAND)} home"{' aria-current="page"' if ctx.route == '' else ''}>
      <span class="nav-brand__mark">{lib.svg_inline('assets/brand/logo-mark.svg')}</span>
      {wordmark(ctx, 'nav-brand__word')}
    </a>
    <ul class="nav-links" role="list">{links}</ul>
    <div class="nav-actions">
      {button(ctx, 'Start a Project', ctx.url('contact'), variant='dark', cls='btn--sm nav-cta')}
      <button class="nav-toggle" type="button" aria-expanded="false" aria-controls="site-menu" data-menu-open>
        <span class="nav-toggle__icon" aria-hidden="true"><i></i><i></i></span><span class="sr-only">Open menu</span>
      </button>
    </div>
  </nav>
</header>'''


def document(ctx, title, description, body, *, footer_cta=True):
    full_title = f'{title} — {CONFIG["brand_full"]}' if title else f'{CONFIG["brand_full"]} — {CONFIG["tagline"]}'
    b = ctx.base
    og = ctx.asset('assets/brand/og-image.jpg')
    site_url = CONFIG.get('site_url') or ''
    canonical = f'<link rel="canonical" href="{E(site_url.rstrip("/") + "/" + (ctx.route + "/" if ctx.route else ""))}">' if site_url else ''
    menu = _safe('chrome_menu', 'render', ctx)
    footer = _safe('chrome_footer', 'render', ctx, cta=footer_cta and ctx.page not in ('contact', 'notfound'))
    return f'''<!doctype html>
<html lang="en" class="no-js">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{E(full_title)}</title>
<meta name="description" content="{E(description)}">
<meta name="theme-color" content="#f2f2f2">
{'' if CONFIG.get('indexable') else '<meta name="robots" content="noindex,nofollow">'}
<meta property="og:type" content="website">
<meta property="og:title" content="{E(full_title)}">
<meta property="og:description" content="{E(description)}">
<meta property="og:image" content="{og}">
<meta name="twitter:card" content="summary_large_image">
{canonical}
<link rel="icon" href="{ctx.asset('assets/brand/favicon.svg')}" type="image/svg+xml">
<link rel="icon" href="{ctx.asset('assets/brand/favicon-32.png')}" sizes="32x32" type="image/png">
<link rel="apple-touch-icon" href="{ctx.asset('assets/brand/apple-touch-icon-180.png')}">
<script>(function(d){{d.className=d.className.replace('no-js','js');try{{if(!matchMedia('(prefers-reduced-motion: reduce)').matches)d.classList.add('motion')}}catch(e){{}}}})(document.documentElement)</script>
<link rel="preload" href="{b}assets/geist.woff2" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="{b}styles.css">
<script src="{b}app.js" defer></script>
</head>
<body class="page-{ctx.page}">
<a class="skip-link" href="#main">Skip to content</a>
{header(ctx)}
{menu}
<main id="main" tabindex="-1">
{body}
</main>
{footer}
<div class="page-shade" aria-hidden="true"></div>
</body>
</html>
'''
