"""Shared service-card renderer (reference SERVICES rows, ref-services-testimonials §2).

Used by the home overview (sections/home_services.py) and the What We Create page
(pages/create.py). CSS: src/css/22-services.css (.svc-*). JS: src/js/22-services.js
(the reference "works" stack + Tap Here badge on the Website Design image card, §2.7).

Building blocks
  row(ctx, s, ...)        grey frame (r48, p16) = info card + image card ("large row")
  small_row(ctx, items)   grey frame holding up to three small cards (text + chips + artwork)
  folder(n)               47x48 folder icon whose papers pop out on hover (reference §2.6)
  chips(tags, ...)        reference tag chips with small stroke icons (drawn for this site)

Copy comes from content.CREATE; imagery is the supplied project work mapped by service.
"""
import re
import lib
from lib import E, roll
import projects
from content import PRIMARY_CTA

# ------------------------------------------------------------------ imagery per service
# Each service shows work from the project whose supplied services match it best
# (scripts/projects.py). 'images' = [primary, secondary, ...]; AI & Automation has no
# matching project, so it gets the brand-mark card instead of borrowed imagery.
MEDIA = {
    # 03 / 10 are 16:9 site mocks on a pure-black ground: letterboxed (contain on black) so the
    # mock's headline and side copy are never cut by the 1.33 card; 08 (portrait) stays cover.
    '01': {'slug': 'taurus-arena', 'images': ['projects-taurus-arena-03', 'projects-taurus-arena-08', 'projects-taurus-arena-10'], 'pos': '50% 50%',
           'contain': ('projects-taurus-arena-03', 'projects-taurus-arena-10')},
    '02': {'slug': 'hocl-labs', 'images': ['projects-hocl-labs-07', 'projects-hocl-labs-03'], 'pos': '62% 50%'},
    '03': {'slug': 'fragile-base', 'images': ['projects-fragile-base-10', 'projects-fragile-base-12'], 'pos': '40% 50%'},
    # Evermark has a single supplied image: the small card's back print is a detail crop of it.
    '04': {'slug': 'evermark-global', 'images': ['home-02'], 'pos': '50% 50%', 'detail': ('58% 40%', 1.9)},
    '05': {'slug': 'aesthetic-origins', 'images': ['projects-aesthetic-origins-01', 'projects-aesthetic-origins-02'], 'pos': '50% 50%'},
    '06': {'slug': 'tafuta', 'images': ['projects-tafuta-07', 'projects-tafuta-05'], 'pos': '50% 60%'},
    '07': {'slug': None, 'images': []},
    '08': {'slug': 'aesthetic-origins', 'images': ['projects-aesthetic-origins-09', 'projects-aesthetic-origins-03'], 'pos': '50% 50%'},
}

ROW_SIZES = '(min-width:1440px) 584px, (min-width:1200px) 46vw, (min-width:800px) calc(100vw - 128px), calc(100vw - 48px)'
ART_SIZES = '(min-width:1200px) 290px, (min-width:800px) 300px, 70vw'


def slug(name):
    return re.sub(r'[^a-z0-9]+', '-', name.lower().replace('&', ' ')).strip('-')


def _typo(text):
    return text.replace("'", '’')


# ------------------------------------------------------------------ chip icons (20x20 stroke)
_I = {
    'compass': '<circle cx="10" cy="10" r="7.75"/><path d="m12.9 7.1-1.6 4.2-4.2 1.6 1.6-4.2z"/>',
    'route': '<circle cx="5" cy="15" r="2"/><circle cx="15" cy="4.5" r="2"/><path d="M7 15h5.25a2.75 2.75 0 0 0 0-5.5h-4.5a2.5 2.5 0 0 1 0-5H13"/>',
    'wireframe': '<rect x="2.5" y="3" width="15" height="14" rx="3"/><path d="M2.5 7.5h15M8 7.5V17"/>',
    'layers': '<path d="m10 2.75 7.25 3.75L10 10.25 2.75 6.5z"/><path d="m2.75 10 7.25 3.75L17.25 10M2.75 13.5l7.25 3.75 7.25-3.75"/>',
    'devices': '<rect x="1.75" y="3.5" width="11.5" height="9" rx="2"/><path d="M5.25 16h4.5M7.5 12.5V16"/><rect x="14.75" y="7" width="3.75" height="9" rx="1.25"/>',
    'cursor': '<path d="M4.5 3.5 15.5 8l-4.75 1.75L9 14.5z"/><path d="m10.75 9.75 4.5 4.5"/>',
    'components': '<path d="m10 2.25 2.75 2.75L10 7.75 7.25 5zM5 7.25 7.75 10 5 12.75 2.25 10zM15 7.25 17.75 10 15 12.75 12.25 10zM10 12.25l2.75 2.75L10 17.75 7.25 15z"/>',
    'tap': '<path d="m8.5 8.5 8 3-3.5 1.5-1.5 3.5z"/><path d="M8.5 2.75V4.5M2.75 8.5H4.5M4.4 4.4l1.25 1.25M12.6 4.4l-1.25 1.25M4.4 12.6l1.25-1.25"/>',
    'briefcase': '<rect x="2.5" y="6" width="15" height="11" rx="2.5"/><path d="M7 6V4.75C7 3.78 7.78 3 8.75 3h2.5c.97 0 1.75.78 1.75 1.75V6M2.5 10.5h15"/>',
    'building': '<path d="M3.75 17.25V4.5c0-.83.67-1.5 1.5-1.5h5.5c.83 0 1.5.67 1.5 1.5v12.75M12.25 8h2.5c.83 0 1.5.67 1.5 1.5v7.75M2 17.25h16M6.5 6.5h2.5M6.5 9.5h2.5M6.5 12.5h2.5"/>',
    'page': '<rect x="3.5" y="2.5" width="13" height="15" rx="2.5"/><path d="M6.75 6.5h6.5M6.75 9.25h4"/><rect x="6.75" y="12" width="4.5" height="2.5" rx="1.25"/>',
    'database': '<ellipse cx="10" cy="5" rx="6.25" ry="2.5"/><path d="M3.75 5v10c0 1.38 2.8 2.5 6.25 2.5s6.25-1.12 6.25-2.5V5M3.75 10c0 1.38 2.8 2.5 6.25 2.5s6.25-1.12 6.25-2.5"/>',
    'browser': '<rect x="2" y="3.5" width="16" height="13" rx="2.5"/><path d="M2 7.5h16M4.75 5.5h.01M6.75 5.5h.01M5.5 10.75h5M5.5 13.25h3"/>',
    'tag': '<path d="M10.6 2.75h5.15c.83 0 1.5.67 1.5 1.5V9.4c0 .4-.16.78-.44 1.06l-6.3 6.3a1.5 1.5 0 0 1-2.12 0L3.24 11.6a1.5 1.5 0 0 1 0-2.12l6.3-6.3c.28-.28.66-.44 1.06-.44z"/><circle cx="13.75" cy="6.25" r="1.25"/>',
    'bag': '<path d="M4.25 6.75h11.5l-.85 9.15a1.75 1.75 0 0 1-1.74 1.6H6.84a1.75 1.75 0 0 1-1.74-1.6z"/><path d="M7.25 8.75V5.5a2.75 2.75 0 0 1 5.5 0v3.25"/>',
    'cart': '<path d="M2 3h2.1l1.95 9.4a1.5 1.5 0 0 0 1.47 1.2h7.1a1.5 1.5 0 0 0 1.46-1.15L17.5 6.5H5"/><circle cx="7.75" cy="16.75" r="1.25"/><circle cx="14.25" cy="16.75" r="1.25"/>',
    'card': '<rect x="2" y="4.5" width="16" height="11" rx="2.5"/><path d="M2 8.5h16M5 12.25h3"/>',
    'clipboard': '<path d="M7.25 3.5H6a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2v-10a2 2 0 0 0-2-2h-1.25"/><rect x="7.25" y="2" width="5.5" height="3" rx="1"/><path d="m7 10.25 1.5 1.5 3.5-3.5M7 14.5h6"/>',
    'phone': '<rect x="5" y="2" width="10" height="16" rx="2.5"/><path d="M8.5 15h3"/>',
    'scroll': '<rect x="5.25" y="2.25" width="9.5" height="15.5" rx="4.75"/><path d="M10 5.75v2.5"/>',
    'story': '<path d="M10 5.25C8.5 3.9 6.25 3.4 2.75 3.6v11c3.5-.2 5.75.3 7.25 1.65 1.5-1.35 3.75-1.85 7.25-1.65v-11c-3.5-.2-5.75.3-7.25 1.65zM10 5.25v11"/>',
    'toggle': '<rect x="2" y="5.5" width="16" height="9" rx="4.5"/><circle cx="13.5" cy="10" r="2.25"/>',
    'film': '<rect x="2.5" y="3" width="15" height="14" rx="2.5"/><path d="M6.5 3v14M13.5 3v14M2.5 7.5h4M2.5 12.5h4M13.5 7.5h4M13.5 12.5h4"/>',
    'cube': '<path d="M10 2.5 16.5 6.25v7.5L10 17.5l-6.5-3.75v-7.5z"/><path d="M3.5 6.25 10 10l6.5-3.75M10 10v7.5"/>',
    'type': '<path d="M4 5.25V3.5h12v1.75M10 3.5v13M7.5 16.5h5"/>',
    'drop': '<path d="M10 2.5c-3 3.6-5 6.35-5 9a5 5 0 0 0 10 0c0-2.65-2-5.4-5-9z"/><path d="M7.75 11.75A2.25 2.25 0 0 0 10 14"/>',
    'eye': '<path d="M1.75 10C3.6 6.2 6.5 4.5 10 4.5s6.4 1.7 8.25 5.5c-1.85 3.8-4.75 5.5-8.25 5.5S3.6 13.8 1.75 10z"/><circle cx="10" cy="10" r="2.75"/>',
    'id': '<rect x="2" y="4" width="16" height="12" rx="2.5"/><circle cx="7" cy="9" r="1.75"/><path d="M4.5 13.25c.4-1.3 1.4-2 2.5-2s2.1.7 2.5 2M12 8.5h3.5M12 11.5h2.5"/>',
    'book': '<path d="M4.25 15.5V4.25C4.25 3 5.25 2 6.5 2h9.25v11.25H6.5a2.25 2.25 0 0 0 0 4.5h9.25"/><path d="M8 6h4.25"/>',
    'gauge': '<path d="M3.25 14.5a6.75 6.75 0 1 1 13.5 0"/><path d="m10 14.5 3-3.75M3.25 17.25h13.5"/>',
    'bars': '<path d="M4 16.5V11M8 16.5V7M12 16.5v-6M16 16.5V4"/>',
    'cloud': '<path d="M6 15.5a3.75 3.75 0 0 1-.55-7.46A5 5 0 0 1 15 7.6a3.95 3.95 0 0 1-.25 7.9z"/>',
    'flow': '<rect x="2.5" y="2.5" width="5.5" height="5.5" rx="1.5"/><rect x="12" y="12" width="5.5" height="5.5" rx="1.5"/><path d="M8 5.25h3.25a3.5 3.5 0 0 1 3.5 3.5V12M13 10.25 14.75 12l1.75-1.75"/>',
    'loop': '<path d="M16.25 8A6.5 6.5 0 0 0 4.1 6.5M3.75 12a6.5 6.5 0 0 0 12.15 1.5"/><path d="M16.5 3.5V8H12M3.5 16.5V12H8"/>',
    'chat': '<path d="M3 5.5A2.5 2.5 0 0 1 5.5 3h9A2.5 2.5 0 0 1 17 5.5v6a2.5 2.5 0 0 1-2.5 2.5H9.5L6 17v-3h-.5A2.5 2.5 0 0 1 3 11.5z"/><path d="M10 5.75c.3 1.5.85 2.05 2.25 2.25-1.4.2-1.95.75-2.25 2.25-.3-1.5-.85-2.05-2.25-2.25 1.4-.2 1.95-.75 2.25-2.25z"/>',
    'spark': '<path d="M9 2.5c.6 3.6 1.9 4.9 5.5 5.5-3.6.6-4.9 1.9-5.5 5.5-.6-3.6-1.9-4.9-5.5-5.5 3.6-.6 4.9-1.9 5.5-5.5z"/><path d="M15 12.5c.25 1.35.75 1.85 2.25 2.25-1.5.4-2 .9-2.25 2.25-.25-1.35-.75-1.85-2.25-2.25 1.5-.4 2-.9 2.25-2.25z"/>',
    'wrench': '<path d="M12.75 2.9a4.25 4.25 0 0 0-5.1 5.6l-4.6 4.6a1.95 1.95 0 0 0 2.75 2.75l4.6-4.6a4.25 4.25 0 0 0 5.6-5.1l-2.6 2.6-2.25-.5-.5-2.25z"/>',
    'code': '<path d="M6.5 6 2.5 10l4 4M13.5 6l4 4-4 4M11.25 4l-2.5 12"/>',
    'target': '<circle cx="10" cy="10" r="7.5"/><circle cx="10" cy="10" r="4"/><circle cx="10" cy="10" r=".6"/>',
    'map': '<path d="m2.5 5 5-2 5 2 5-2v12l-5 2-5-2-5 2z"/><path d="M7.5 3v12M12.5 5v12"/>',
    'search': '<circle cx="9" cy="9" r="5.75"/><path d="m13.25 13.25 4.25 4.25"/>',
    'scale': '<path d="M10 3v14M6.5 17h7M4 6.25h12"/><path d="M4 6.25 1.75 11a2.25 2.25 0 0 0 4.5 0zM16 6.25 13.75 11a2.25 2.25 0 0 0 4.5 0z"/>',
    'structure': '<rect x="7.5" y="2.5" width="5" height="4" rx="1.2"/><rect x="2.5" y="13.5" width="5" height="4" rx="1.2"/><rect x="12.5" y="13.5" width="5" height="4" rx="1.2"/><path d="M10 6.5V10.5M5 13.5V12c0-.83.67-1.5 1.5-1.5h7c.83 0 1.5.67 1.5 1.5v1.5"/>',
    'trend': '<path d="m2.5 14.5 5-5 3.5 3.5 6.5-6.5M12.5 6.5h5v5"/>',
    'dot': '<circle cx="10" cy="10" r="3"/>',
}

TAG_ICON = {
    'UX Strategy': 'compass', 'User Journeys': 'route', 'Wireframes': 'wireframe', 'UI Design': 'layers',
    'Responsive Design': 'devices', 'Prototyping': 'cursor', 'Design Systems': 'components', 'Interaction Design': 'tap',
    'Business Websites': 'briefcase', 'Corporate Websites': 'building', 'Landing Pages': 'page', 'CMS Websites': 'database',
    'Interactive Websites': 'tap', 'Web Applications': 'browser',
    'Product Pages': 'tag', 'Shopping Experiences': 'bag', 'Cart & Checkout': 'cart', 'Payment Integration': 'card',
    'Order Management': 'clipboard', 'CMS': 'database', 'Mobile Experiences': 'phone',
    'Scroll animations': 'scroll', 'Interactive storytelling': 'story', 'Product interactions': 'cube',
    'Micro-interactions': 'toggle', 'Cinematic experiences': 'film', '3D environments': 'cube',
    'Typography': 'type', 'Colour Systems': 'drop', 'Visual Direction': 'eye', 'Digital Identity': 'id', 'Brand Guidelines': 'book',
    'Dashboards': 'gauge', 'SaaS Platforms': 'cloud', 'Mobile Interfaces': 'phone', 'User Flows': 'flow', 'Prototypes': 'cursor',
    'AI Experiences': 'spark', 'Workflow Automation': 'loop', 'AI Interfaces': 'chat', 'Internal Tools': 'wrench',
    'Intelligent Dashboards': 'bars', 'API Integrations': 'code',
    'Digital Positioning': 'target', 'Website Strategy': 'map', 'User Research': 'search', 'Competitor Analysis': 'scale',
    'Content Structure': 'structure', 'Conversion Strategy': 'trend',
}
# 'Product interactions' reads better as a pointer than a second cube.
TAG_ICON['Product interactions'] = 'tap'


def chip_icon(tag):
    return f'<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false">{_I[TAG_ICON.get(tag, "dot")]}</svg>'


def chips(tags, cls='', *, limit=None, more_href=None, name=''):
    """Tag chips. With limit, only the first tags are shown plus a '+N' chip that links to the
    full list (more_href) — used by the compact home cards."""
    shown = tags[:limit] if limit else tags
    items = ''.join(f'<li class="svc-chip">{chip_icon(t)}<span>{E(t)}</span></li>' for t in shown)
    rest = len(tags) - len(shown)
    if rest > 0 and more_href:
        label = f'{name}: see all {len(tags)} on the What We Create page'
        items += (f'<li><a class="svc-chip svc-chip--more" href="{E(more_href)}" aria-label="{E(label)}">'
                  f'<span aria-hidden="true">+{rest}</span>{lib.ICONS["arrow-ne"]}</a></li>')
    return f'<ul class="svc-chips{(" " + cls) if cls else ""}" role="list">{items}</ul>'


# ------------------------------------------------------------------ folder icon (reference §2.6)
_FOLDER_IDS = {}


def _folder_back(n):
    # gradient ids must be unique per document: number them per service and per use
    k = _FOLDER_IDS[n] = _FOLDER_IDS.get(n, 0) + 1
    gid = f'svcFolder{n}x{k}'
    return ('<svg class="svc-folder__back" viewBox="0 0 47 48" aria-hidden="true" focusable="false">'
            f'<defs><linearGradient id="{gid}" x1="0" y1="0" x2="0" y2="1">'
            '<stop offset="0" stop-color="#4c5054"/><stop offset="1" stop-color="#2a2f38"/></linearGradient></defs>'
            '<path d="M8 0h11.6c1.95 0 3.7 1.05 4.65 2.75l1.5 2.7c.38.68 1.1 1.1 1.88 1.1H39c4.4 0 8 3.6 8 8V40c0 4.4-3.6 8-8 8H8'
            f'c-4.4 0-8-3.6-8-8V8c0-4.4 3.6-8 8-8z" fill="url(#{gid})" stroke="#585858" stroke-width=".25"/></svg>')


def folder(n):
    """Folder with two papers (the front one carries the service number); papers lift out on hover."""
    paper = ('<svg viewBox="0 0 40 39" aria-hidden="true" focusable="false">'
             '<rect x=".25" y=".25" width="39.5" height="38.5" rx="4" fill="#f4f4f4" stroke="#e3e3e3" stroke-width=".5"/>'
             f'<text x="5" y="10.5" font-size="6.5" font-weight="600" fill="#161616" font-family="Geist Mono, ui-monospace, monospace" letter-spacing=".2">{E(n)}</text>'
             '<path d="M5 15h22M5 18.5h16M5 22h19" stroke="#cfcfcf" stroke-width="1.2" stroke-linecap="round"/>'
             '<circle cx="33" cy="8" r="1.6" fill="#fb2629"/></svg>')
    return (f'<span class="svc-folder" aria-hidden="true">{_folder_back(n)}'
            f'<span class="svc-folder__paper svc-folder__paper--back"></span>'
            f'<span class="svc-folder__paper svc-folder__paper--front">{paper}</span>'
            f'<span class="svc-folder__lip"></span><span class="svc-folder__front"></span></span>')


# ------------------------------------------------------------------ image cards
def _caption(p):
    """Unobtrusive project caption (decorative: the link carries the accessible name)."""
    arrow = lib.ICONS['arrow-ne']
    return (f'<span class="svc-cap" aria-hidden="true"><i class="svc-cap__dot"></i>'
            f'<span class="svc-cap__title">{roll(p["title"])}</span>'
            f'<span class="svc-cap__icon">{arrow}</span></span>')


def _alt(p, s):
    return f'{p["title"]} — {p["industry"]} project imagery ({s["name"]})'


# AI & Automation has no project of its own: the brand's 3D mark on a deep gradient with
# construction rings; on the large card its tags float around the mark like the reference's
# 2D & 3D tag pills. (position, rotation, drift on hover)
_PILLS = [
    ('left:7%;top:13%', -6, (-10, -6)),
    ('right:6%;top:19%', 5, (10, -6)),
    ('left:4%;top:47%', 4, (-12, 0)),
    ('right:4%;top:53%', -4, (12, 0)),
    ('left:11%;bottom:13%', -3, (-8, 8)),
    ('right:10%;bottom:15%', 6, (8, 8)),
]


def _brand_panel(ctx, cls, size=240, tags=()):
    rings = ('<i class="svc-brand__glow"></i><i class="svc-brand__ring svc-brand__ring--1"></i>'
             '<i class="svc-brand__ring svc-brand__ring--2"></i>'
             '<i class="svc-brand__orbit"><b></b><b></b></i><i class="svc-brand__axis"></i>')
    pills = ''.join(
        f'<span class="svc-pill" style="{pos};--r:{r}deg;--dx:{dx}px;--dy:{dy}px;--i:{i}">{chip_icon(t)}<span>{E(t)}</span></span>'
        for i, (t, (pos, r, (dx, dy))) in enumerate(zip(tags, _PILLS)))
    mark = lib.img(ctx, 'assets/brand/logo-mark-3d.webp', '', w=size, h=round(size * 519 / 515), cls='svc-brand__mark')
    return f'<div class="svc-brand {cls}" aria-hidden="true">{rings}{pills}{mark}</div>'


_FLOW_IDS = [0]


def _flow_card():
    """Back card of the AI & Automation small card: an automation flow drawn for this site
    (three steps wired together; the dark middle one is the AI step)."""
    _FLOW_IDS[0] += 1
    pid = f'svcFlowDots{_FLOW_IDS[0]}'

    def node(x, y, dark=False, accent=False):
        fill, bar = ('#161616', 'rgba(255,255,255,.55)') if dark else ('#fff', '#dcdcdc')
        sq = '#fb2629' if accent else ('#fff' if dark else '#161616')
        return (f'<rect x="{x}" y="{y}" width="66" height="26" rx="8" fill="{fill}" stroke="rgba(0,0,0,.1)" stroke-width=".75"/>'
                f'<rect x="{x + 7}" y="{y + 7}" width="12" height="12" rx="4" fill="{sq}"/>'
                f'<rect x="{x + 25}" y="{y + 8.5}" width="30" height="3.5" rx="1.75" fill="{bar}"/>'
                f'<rect x="{x + 25}" y="{y + 15}" width="20" height="3" rx="1.5" fill="{bar}" opacity=".7"/>')
    return (f'<svg class="svc-flow" viewBox="0 0 200 150" preserveAspectRatio="xMidYMid slice" aria-hidden="true" focusable="false">'
            f'<defs><pattern id="{pid}" width="10" height="10" patternUnits="userSpaceOnUse">'
            f'<circle cx="1.5" cy="1.5" r=".9" fill="rgba(0,0,0,.13)"/></pattern></defs>'
            f'<rect width="200" height="150" fill="url(#{pid})"/>'
            f'<path class="svc-flow__wire" d="M82 37C104 37 98 75 118 75"/>'
            f'<path class="svc-flow__wire" d="M151 88C151 112 110 113 82 113"/>'
            f'{node(16, 24)}{node(118, 62, dark=True, accent=True)}{node(16, 100)}'
            f'<circle cx="82" cy="37" r="2.5" fill="#161616"/><circle cx="82" cy="113" r="2.5" fill="#161616"/></svg>')


def media(ctx, s, *, stack=False):
    """Right-hand image card of a large row: project imagery linked through lib.project_tag
    (View Project cursor). stack=True renders the reference "works" stack: the next image peeks
    from the bottom-right corner; a click on it (or the Tap Here badge) brings it forward."""
    m = MEDIA[s['n']]
    if not m['slug']:
        return f'<div class="svc-media svc-media--brand">{_brand_panel(ctx, "svc-media__card", 300, s["tags"])}</div>'
    p = projects.by_slug(m['slug'])
    pos = m.get('pos', '50% 50%')
    imgs = m['images'] if stack else m['images'][:1]
    cards = []
    for k, name in enumerate(imgs):
        extra = f'data-stack-card data-pos="{k}"' + (' tabindex="-1" aria-hidden="true"' if k else '')
        dark = name in m.get('contain', ())
        cls = 'svc-media__card' + (' svc-media__card--dark' if dark else '')
        o, c = lib.project_tag(ctx, p, cls, extra=extra if stack else '')
        alt = _alt(p, s) if not k else f'{p["title"]} — {p["industry"]} project imagery, image {k + 1} of {len(imgs)}'
        fit = 'object-fit:contain' if dark else f'object-position:{pos}'
        pic = lib.picture(ctx, name, alt, sizes=ROW_SIZES, max_width=1280, attrs=f'style="{fit}"')
        cards.append(f'{o}<span class="svc-media__img reveal-image">{pic}</span>{_caption(p)}{c}')
    if not stack:
        return f'<div class="svc-media">{"".join(cards)}</div>'
    tap = ('<button class="svc-tap" type="button" data-stack-next aria-label="Show the next image of this project">'
           '<span class="svc-tap__icon" aria-hidden="true"><svg viewBox="0 0 20 20" focusable="false">'
           '<path d="M15.5 3.5v5.25a3.25 3.25 0 0 1-3.25 3.25H4.5M8 8.5 4.5 12 8 15.5" fill="none" stroke="currentColor" '
           'stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></span>'
           '<span class="svc-tap__label">Tap Here</span></button>')
    status = '<span class="sr-only" data-stack-status aria-live="polite"></span>'
    return f'<div class="svc-media svc-media--stack" data-svc-stack>{"".join(cards)}{tap}{status}</div>'


# ------------------------------------------------------------------ info card + rows
def _desc(s, cls='svc-info__desc'):
    lead = f'<span class="svc-lead">{E(_typo(s["title"]))}</span>'
    body = f' {E(_typo(s["body"]))}' if s.get('body') else ''
    return f'<p class="{cls}">{lead}{body}</p>'


def contact_href(ctx, s):
    """Contact page with this service pre-selected (src/js/35-contact.js reads ?service=)."""
    return f'{ctx.url("contact")}?service={slug(s["name"])}'


def _cta(ctx, s):
    arrow = lib.ICONS['arrow-r']
    return (f'<div class="svc-info__foot"><a class="svc-cta" data-letter-roll href="{E(contact_href(ctx, s))}" '
            f'aria-label="{E(PRIMARY_CTA)}: {E(s["name"])}"><span class="svc-cta__label">{roll(PRIMARY_CTA)}</span>'
            f'<span class="svc-cta__icon" aria-hidden="true">{arrow}</span></a></div>')


def info(ctx, s, *, hid, tag='h3', number=False, total=8, note=False, cta=False):
    num = (f'<span class="svc-info__num" aria-hidden="true"><b>{E(s["n"])}</b>/{total:02d}</span>' if number else '')
    note_html = (f'<p class="svc-info__note"><i aria-hidden="true"></i>{E(_typo(s["note"]))}</p>'
                 if note and s.get('note') else '')
    return (f'<div class="svc-info">'
            f'<div class="svc-info__text"><div class="svc-info__top">{folder(s["n"])}{num}</div>'
            f'<{tag} class="svc-info__title" id="{hid}">{E(s["name"])}</{tag}>{_desc(s)}{note_html}</div>'
            f'{chips(s["tags"])}{_cta(ctx, s) if cta else ""}</div>')


def row(ctx, s, *, tag='h3', flip=False, number=False, note=False, stack=False, anchor=False, cta=False, reveal=True):
    """Large framed row: info card + image card (reference rows 1-2)."""
    sid = slug(s['name'])
    hid = f'svc-{sid}-title'
    rid = f' id="{sid}"' if anchor else ''
    rev = ' data-reveal style="--y:60px"' if reveal else ''
    mods = (' svc-row--flip' if flip else '') + (' svc-row--cta' if cta else '')
    return (f'<article class="svc-frame svc-row{mods}"{rid} aria-labelledby="{hid}"{rev}>'
            f'{info(ctx, s, hid=hid, tag=tag, number=number, note=note, cta=cta)}{media(ctx, s, stack=stack)}</article>')


# ------------------------------------------------------------------ small cards (reference §2.8-2.9)
def _art(ctx, s):
    m = MEDIA[s['n']]
    if not m['slug']:
        back = f'<span class="svc-art__card svc-art__card--back svc-art__card--paper" aria-hidden="true">{_flow_card()}</span>'
        front = _brand_panel(ctx, 'svc-art__card svc-art__card--front', 180)
        return f'<div class="svc-art svc-art--brand">{back}{front}</div>'
    p = projects.by_slug(m['slug'])
    o, c = lib.project_tag(ctx, p, 'svc-art')
    pos = m.get('pos', '50% 50%')
    if len(m['images']) > 1:
        back_img = lib.picture(ctx, m['images'][1], '', sizes=ART_SIZES, max_width=640)
    else:  # a single supplied image: the back print is a detail crop of it
        dpos, zoom = m.get('detail', ('50% 50%', 1.6))
        back_img = lib.picture(ctx, m['images'][0], '', sizes=ART_SIZES, max_width=1280,
                               attrs=f'style="transform-origin:{dpos};transform:scale({zoom})"')
    back = f'<span class="svc-art__card svc-art__card--back" aria-hidden="true">{back_img}</span>'
    front_img = lib.picture(ctx, m['images'][0], _alt(p, s), sizes=ART_SIZES, max_width=1280, attrs=f'style="object-position:{pos}"')
    front = f'<span class="svc-art__card svc-art__card--front reveal-image">{front_img}</span>'
    return f'{o}{back}{front}{_caption(p)}{c}'


def small(ctx, s, *, tag='h3', more_href=None):
    sid = slug(s['name'])
    hid = f'svc-{sid}-title'
    tags = chips(s['tags'], 'svc-chips--compact', limit=3, more_href=more_href, name=s['name']) if more_href else ''
    return (f'<article class="svc-small" aria-labelledby="{hid}">'
            f'<div class="svc-small__text"><{tag} class="svc-small__title" id="{hid}">{E(s["name"])}</{tag}>'
            f'{_desc(s, "svc-small__desc")}{tags}</div>'
            f'<div class="svc-small__art">{_art(ctx, s)}</div></article>')


def small_row(ctx, items, *, tag='h3', more=None):
    """Grey frame of up to three small cards. more(s) -> href of the service's full entry."""
    cards = ''.join(small(ctx, s, tag=tag, more_href=more(s) if more else None) for s in items)
    return f'<div class="svc-frame svc-smalls" data-reveal style="--y:60px">{cards}</div>'
