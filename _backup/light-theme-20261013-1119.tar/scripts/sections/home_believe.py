"""Home — section 4: WHAT WE BELIEVE + OUR NUMBERS (reference `#testimonials`,
ref-services-testimonials §3).

Reference layout: pill → two-line H2 → one-line sub, then the coverflow Slideshow (584 px
container, 560 px slides, 24 px gap, side cards at 10 % / scale .8 / rotateY ±20° around their
inner edge, perspective 700, 700 ms cubic-bezier(.44,0,.56,1), 4 s autoplay, drag, dots).

The reference's client testimonials are replaced by statements and numbers taken verbatim from
the content document (HOME.believe, HOME.numbers, BRAND idea): no quotes, names, ratings or
avatars are invented. Each card keeps the testimonial-card anatomy — mono counter where the stars
were, bold-highlighted statement, brand mark + "{brand}" where the client avatar/name were, stat
tiles — so the section reads exactly like the reference.

`carousel()` and `card()` are generic and reused by pages/stories.py for real testimonials once
they are supplied in content.STORIES['testimonials'].
"""
import re

import lib
from lib import E, fmt, BRAND, ICONS, pill_label, svg_inline
from content import HOME, BRAND as BRAND_COPY

# Small upward trend line (reference stat icon, 22x20, drawn in brand red instead of green).
TREND = ('<svg class="bel-card__trend" viewBox="0 0 22 20" width="22" height="20" aria-hidden="true" focusable="false">'
         '<path d="M2.03 16.44 6.77 12.09a.5.5 0 0 1 .65-.02l3.45 2.74a.5.5 0 0 0 .67-.05l6.88-7.17M15.8 6.91l2.35.08'
         'c.46.02.82.4.81.86l-.04 2.56" fill="none" stroke="currentColor" stroke-width="1.35" stroke-linecap="round" '
         'stroke-linejoin="round"/></svg>')

# Hand-drawn underline under "Simple" (reference scribble device, drawn on with stroke-dashoffset).
SWASH = ('<svg class="bel__swash" viewBox="0 0 200 22" preserveAspectRatio="none" aria-hidden="true" focusable="false">'
         '<path d="M4 15.5C38 9 92 5.6 140 6.4c20 .3 38 1.6 56 3.9" pathLength="1"/>'
         '<path d="M30 18.4c44-4.3 96-5.6 150-2.2" pathLength="1"/></svg>')

DOTS = '<span class="bel-card__dots" aria-hidden="true"><i></i><i></i><i></i><i></i></span>'


def T(text):
    """Visible copy with typographic apostrophes (house style, as in HOME.idea)."""
    return fmt(text).replace("'", '’')


def _bold(text, phrases, *, em=False):
    """Escape text and wrap each phrase (verbatim substring) in <strong> (reference highlight)."""
    out = E(T(text))
    for ph in phrases:
        ph_e = E(T(ph))
        tag_open, tag_close = ('<em><strong>', '</strong></em>') if em else ('<strong>', '</strong>')
        out = out.replace(ph_e, f'{tag_open}{ph_e}{tag_close}', 1)
    return out


def _count_attrs(value):
    """data-count attributes for numeric stats such as 20K+ / 400K+ (count-up when visible)."""
    m = re.fullmatch(r'(\d+)(\D*)', value)
    if not m:
        return ''
    return f' data-count="{m.group(1)}" data-suffix="{E(m.group(2))}"'


def tile(value, label, *, trend=False, html_value=None):
    count = _count_attrs(value)
    if html_value:
        num = html_value
    elif count:   # animated digits are decorative; the final value is always in the accessibility tree
        num = f'<span class="bel-card__val" aria-hidden="true"{count}>{E(value)}</span><span class="sr-only">{E(value)}</span>'
    else:
        num = f'<span class="bel-card__val">{E(value)}</span>'
    icon = TREND if trend else ''
    return (f'<li class="bel-card__tile"><span class="bel-card__num">{num}{icon}</span>'
            f'<span class="bel-card__label">{E(label)}</span></li>')


def avatar_mark():
    """Brand mark in the reference avatar slot (44 px circle, black tile, white flat mark)."""
    return f'<span class="bel-card__avatar" aria-hidden="true">{svg_inline("assets/brand/logo-mark.svg")}</span>'


def card(*, quote_html, name, role, avatar_html='', tiles_html='', kicker_html='', stars=0,
         compact=False, single=False, statement=False, cls=''):
    """Reference testimonial card (Framer component "testimonials").

    kicker_html replaces the star row (used for brand statements); stars are only rendered when a
    real rating is supplied. quote_html is trusted, already-escaped HTML."""
    top = ''
    if stars:
        top = (f'<span class="bel-card__stars" role="img" aria-label="Rated {int(stars)} out of 5">'
               + ''.join(f'<i>{ICONS["star"]}</i>' for _ in range(int(stars))) + '</span>')
    elif kicker_html:
        # the slide's own aria-label ("n of N") already announces the position
        top = f'<span class="bel-card__kicker mono" aria-hidden="true">{kicker_html}</span>'
    who = (f'<div class="bel-card__author">{avatar_html}<span class="bel-card__who">'
           f'<span class="bel-card__name">{name}</span><span class="bel-card__role">{role}</span></span></div>')
    tiles = ''
    if tiles_html:
        mods = (' bel-card__tiles--strip' if compact else '') + (' bel-card__tiles--single' if single else '')
        tiles = f'<ul class="bel-card__tiles{mods}" role="list">{tiles_html}</ul>'
    qcls = 'bel-card__quote' + (' bel-card__quote--statement' if statement else '')
    body = quote_html if quote_html.lstrip().startswith('<blockquote') else f'<p>{quote_html}</p>'
    return (f'<article class="bel-card{(" " + cls) if cls else ""}">{DOTS}{top}'
            f'<div class="{qcls}">{body}</div>{who}{tiles}</article>')


def carousel(slides, *, label, cid, cls=''):
    """Coverflow carousel (reference Framer Slideshow). slides: list of card HTML strings.

    Markup follows the WAI-ARIA tabbed-carousel pattern: region with aria-roledescription
    "carousel", a rotation control, slides as tabpanels labelled "n of N" and dot tabs.
    Without JS the track is a native horizontal scroll-snap list."""
    n = len(slides)
    items = ''.join(
        f'<div class="bel-car__slide" id="{cid}-s{i + 1}" role="tabpanel" aria-roledescription="slide" '
        f'aria-label="{i + 1} of {n}" data-carousel-slide>{s}</div>'
        for i, s in enumerate(slides))
    dots = ''.join(
        f'<button class="bel-car__dot" type="button" role="tab" id="{cid}-t{i + 1}" aria-controls="{cid}-s{i + 1}" '
        f'aria-label="Slide {i + 1}" aria-selected="{"true" if i == 0 else "false"}" tabindex="{0 if i == 0 else -1}">'
        f'<i aria-hidden="true"></i></button>'
        for i in range(n))
    pause = ('<button class="bel-car__play" type="button" data-carousel-toggle aria-label="Stop automatic slide show">'
             '<svg class="bel-car__ic-pause" viewBox="0 0 12 12" aria-hidden="true" focusable="false"><path d="M3.5 2.5v7M8.5 2.5v7" '
             'fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>'
             '<svg class="bel-car__ic-play" viewBox="0 0 12 12" aria-hidden="true" focusable="false"><path d="M3.6 2.2v7.6L9.8 6z" '
             'fill="currentColor" stroke="currentColor" stroke-width="1" stroke-linejoin="round"/></svg></button>') if n > 1 else ''
    controls = (f'<div class="bel-car__controls">'
                f'<div class="bel-car__dots" role="tablist" aria-label="Choose a slide">{dots}</div>{pause}</div>') if n > 1 else ''
    return (f'<section class="bel-car{(" " + cls) if cls else ""}" aria-roledescription="carousel" aria-label="{E(label)}" '
            f'data-carousel data-carousel-direction="right" data-interval="4000">'
            f'<div class="bel-car__viewport" data-carousel-viewport>'
            f'<div class="bel-car__track" data-carousel-track aria-live="off">{items}</div></div>'
            f'{controls}</section>')


def _kicker(i, n):
    return f'{i:02d}<span> / {n:02d}</span>'


def _belief_cards():
    believe, numbers = HOME['believe'], HOME['numbers']
    items = numbers['items']
    name = E(BRAND)
    trend = {'20K+', '400K+', 'Millions'}
    tiles = lambda pairs: ''.join(tile(v, l, trend=v in trend) for v, l in pairs)
    lockup = (f'<span class="bel-card__word">{svg_inline("assets/brand/wordmark.svg", "bel-card__wordmark", label=BRAND)}</span>')
    raw = [
        dict(quote_html=_bold(believe['body'][1], ['beautiful experience', 'clear purpose']),
             role=E(believe['label']), tiles_html=tiles(items[0:2])),
        dict(quote_html=_bold(believe['body'][2], ['complex things feel simple']),
             role=E(believe['label']), tiles_html=tiles(items[2:4]), statement=True),
        dict(quote_html=_bold(numbers['body'], ['a community, a portfolio', 'digital experiences can be better']),
             role=E(numbers['label']), tiles_html=tiles(items), compact=True),
        dict(quote_html=_bold(BRAND_COPY['idea'], ['think differently'], em=True),
             role='Brand Idea', single=True,
             tiles_html=tile('', BRAND_COPY['tagline'], html_value=lockup)),
    ]
    n = len(raw)
    return [card(name=name, avatar_html=avatar_mark(), kicker_html=_kicker(i, n), **c) for i, c in enumerate(raw, 1)]


def render(ctx):
    b = HOME['believe']
    first, _, second = b['title'].partition('. ')
    first_html = E(first + '.')
    lead, _, rest = first_html.partition(' ')
    title_html = (f'<span class="bel__mark">{lead}{SWASH}</span> {rest}<br>{E(second)}' if second else E(b['title']))
    return f'''<section class="bel section" id="believe" aria-labelledby="believe-title">
  <div class="bel__inner">
    <header class="section-head bel__head">
      {pill_label(b['label'])}
      <h2 class="section-head__title bel__title" id="believe-title" data-split>{title_html}</h2>
      <p class="section-head__sub bel__sub" data-reveal style="--d:120ms;--y:24px">{E(T(b['body'][0]))}</p>
    </header>
    <div class="bel__carwrap" data-reveal="fade" style="--d:160ms">
      {carousel(_belief_cards(), label=f"{b['label']} and {HOME['numbers']['label']}", cid='bel', cls='bel__car')}
    </div>
  </div>
</section>'''
