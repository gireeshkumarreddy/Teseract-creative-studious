"""Home — section 5: A DIFFERENT KIND OF AGENCY (reference `#plans`, ref-plans-faq-footer §1).

Reference frame (928 px, #e2e2e2, radius 48, padding 16, gap 16) holding:
  card 1  wide horizontal "website +" price-card: red folder icon · title · description ·
          underline link · black lg-dark button with label swap  |  checklist + #f3f3f3 row
  card 2  Who-We-Are philosophy (title, the four steps as the checklist, link)
  card 3  Who-We-Are promise (title, lines, the question in the #f3f3f3 row, link)
Every card has the reference's four 7 px corner dots. No prices, toggles or badges with claims:
all copy is HOME.agency / WHO verbatim.

dark_button() and underline_link() are reused by pages/stories.py.
"""
import lib
from lib import E, fmt, CONFIG, BRAND, ICONS, pill_label, svg_inline
from content import HOME, WHO, PRIMARY_CTA

DOTS = '<span class="dots" aria-hidden="true"><i></i><i></i><i></i><i></i></span>'


def T(text):
    """Visible copy with typographic apostrophes (house style, as in HOME.idea)."""
    return fmt(text).replace("'", '’')

# Reference checklist seal-check (ref-plans-faq-footer appendix A, 20x29).
SEAL = ('<svg class="agc-seal" viewBox="0 0 20 29" width="20" height="29" aria-hidden="true" focusable="false">'
        '<path d="M15.4448 8.01492C15.6348 8.47431 15.9994 8.83947 16.4585 9.03011L18.0683 9.69694C18.5278 9.88724 18.8928 10.2523 19.0831 10.7117C19.2734 11.1711 19.2734 11.6873 19.0831 12.1467L18.4167 13.7554C18.2263 14.2151 18.2261 14.7318 18.4173 15.1912L19.0825 16.7994C19.1769 17.027 19.2254 17.2709 19.2255 17.5172C19.2255 17.7636 19.177 18.0075 19.0827 18.2351C18.9885 18.4626 18.8503 18.6694 18.6761 18.8436C18.5019 19.0177 18.2951 19.1558 18.0674 19.25L16.4587 19.9164C15.9994 20.1063 15.6342 20.4709 15.4436 20.93L14.7767 22.5399C14.5864 22.9993 14.2214 23.3644 13.762 23.5547C13.3026 23.745 12.7863 23.745 12.3269 23.5547L10.7182 22.8883C10.2588 22.6985 9.74276 22.6989 9.2836 22.8894L7.67374 23.5553C7.21457 23.7451 6.69881 23.745 6.23976 23.5548C5.7807 23.3647 5.41589 23.0001 5.22546 22.5411L4.55844 20.9308C4.36848 20.4714 4.00388 20.1063 3.54477 19.9156L1.93491 19.2488C1.47568 19.0586 1.11078 18.6938 0.920407 18.2346C0.730035 17.7755 0.729777 17.2595 0.919689 16.8001L1.58604 15.1914C1.77587 14.732 1.77548 14.216 1.58496 13.7568L0.919567 12.1458C0.825228 11.9183 0.776651 11.6743 0.776611 11.428C0.776572 11.1817 0.825071 10.9378 0.919337 10.7102C1.0136 10.4826 1.15179 10.2758 1.326 10.1017C1.50021 9.92752 1.70703 9.7894 1.93463 9.69521L3.54334 9.02886C4.00233 8.83908 4.36727 8.47493 4.55805 8.01635L5.22488 6.40649C5.41518 5.94706 5.78019 5.58205 6.23962 5.39175C6.69905 5.20145 7.21526 5.20145 7.67468 5.39175L9.28339 6.0581C9.74283 6.24793 10.2589 6.24754 10.718 6.05702L12.3285 5.39278C12.7879 5.20259 13.304 5.20263 13.7633 5.39289C14.2227 5.58315 14.5876 5.94806 14.778 6.40737L15.445 8.01771L15.4448 8.01492Z" fill="#C2C2C2"/>'
        '<path fill-rule="evenodd" clip-rule="evenodd" d="M13.9166 11.8509C14.0502 11.6411 14.0949 11.3867 14.041 11.1439C13.9871 10.901 13.8389 10.6895 13.6291 10.5559C13.4192 10.4223 13.1649 10.3776 12.922 10.4315C12.6792 10.4854 12.4677 10.6336 12.3341 10.8434L8.66283 16.6122L6.98283 14.5122C6.82751 14.3179 6.60138 14.1933 6.35418 14.1658C6.10699 14.1382 5.85897 14.21 5.6647 14.3653C5.47043 14.5206 5.34582 14.7468 5.31827 14.9939C5.29073 15.2411 5.36251 15.4892 5.51783 15.6834L8.01783 18.8084C8.111 18.925 8.23066 19.0177 8.36687 19.0788C8.50308 19.1398 8.65189 19.1674 8.80093 19.1594C8.94998 19.1513 9.09494 19.1077 9.22376 19.0324C9.35258 18.957 9.46154 18.8519 9.54158 18.7259L13.9166 11.8509Z" fill="#161616"/></svg>')

# Reference "Landing Page+" folder icon (§1.6), recoloured to the brand reds.
FOLDER = ('<span class="agc-folder" aria-hidden="true">'
          '<svg class="agc-folder__back" viewBox="0 0 40 37" focusable="false"><defs>'
          '<linearGradient id="agcFolderBack" x1="20" y1="0" x2="20" y2="36.49" gradientUnits="userSpaceOnUse">'
          '<stop stop-color="#E0090D"/><stop offset="1" stop-color="#4A0507"/></linearGradient></defs>'
          '<path d="M3.9072 0C1.74932 0 0 1.74932 0 3.90721V32.5787C0 34.7366 1.74931 36.4859 3.9072 36.4859H36.0928C38.2507 36.4859 40 34.7366 40 32.5787'
          'V9.52927C40 7.37139 38.2507 5.62207 36.0928 5.62207H24.2512C23.6884 5.62207 23.1691 5.3195 22.8916 4.82991L21.2763 1.98041'
          'C20.5825 0.756435 19.2842 0 17.8772 0H3.9072Z" fill="url(#agcFolderBack)" stroke="#F46260" stroke-width=".25"/></svg>'
          '<span class="agc-folder__papers"><i></i><i></i><i></i><i></i></span>'
          '<span class="agc-folder__front"></span></span>')

# 16px badge glyphs (reference badge icon slot, #7C7C7C).
GLYPH_STEPS = ('<svg viewBox="0 0 16 16" aria-hidden="true" focusable="false"><rect x="1.5" y="9.5" width="3" height="5" rx="1" fill="currentColor"/>'
               '<rect x="6.5" y="6" width="3" height="8.5" rx="1" fill="currentColor"/><rect x="11.5" y="2" width="3" height="12.5" rx="1" fill="currentColor"/></svg>')
GLYPH_PROMISE = ('<svg viewBox="0 0 16 16" aria-hidden="true" focusable="false"><circle cx="8" cy="8" r="6.6" fill="currentColor"/>'
                 '<path d="m5.2 8.2 1.9 1.9 3.8-4" fill="none" stroke="#e8e8e8" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>')


def dark_button(text, alt, href, *, cls='', icon_name=None, external=False, label=None):
    """Reference black Contact button (component framer-Pckah, variant lg-dark): 56 px, radius 16,
    hidden light blob, two labels in a 24 px window that swap on hover (spring 500/60)."""
    ic = f'<span class="agc-btn__icon">{ICONS[icon_name]}</span>' if icon_name else ''
    ext = ' target="_blank" rel="noopener"' if external else ''
    return (f'<a class="agc-btn{(" " + cls) if cls else ""}" href="{E(href)}" aria-label="{E(label or text)}"{ext}>'
            f'<span class="agc-btn__win" aria-hidden="true"><span class="agc-btn__t">{E(T(text))}{ic}</span>'
            f'<span class="agc-btn__t">{E(T(alt))}{ic}</span></span></a>')


def underline_link(text, href, *, cls='', label=None):
    """Reference underline link (component framer-rIPFW): 16/500 label, 1 px grey line that draws
    in from the left on hover and wipes out to the right on leave."""
    lab = f' aria-label="{E(label)}"' if label else ''
    return (f'<a class="agc-link{(" " + cls) if cls else ""}" href="{E(href)}"{lab}>'
            f'<span class="agc-link__t">{E(text)}</span><span class="agc-link__line" aria-hidden="true"></span></a>')


def checklist(items, *, ordered=False, cls=''):
    tag = 'ol' if ordered else 'ul'
    rows = ''.join(f'<li class="agc-check">{SEAL}<span>{E(T(t))}</span></li>' for t in items)
    return f'<{tag} class="agc-list{(" " + cls) if cls else ""}" role="list">{rows}</{tag}>'


def note_row(text_html, *, cls=''):
    """Reference add-on toggle row (#f3f3f3, radius 12, padding 12, 16/600) with a brand dot in
    place of the switch."""
    return (f'<p class="agc-note{(" " + cls) if cls else ""}"><span class="agc-note__dot" aria-hidden="true"></span>'
            f'<span>{text_html}</span></p>')


def _wide_card(ctx):
    a = HOME['agency']
    email = CONFIG.get('email') or ''
    link = underline_link('Prefer email? Write to us ->', f'mailto:{email}', label=f'Prefer email? Write to us at {email}') if email else ''
    title = a['label'][:1] + a['label'][1:].lower()
    return f'''<article class="card agc-card agc-card--wide" aria-labelledby="agency-card-title">
      {DOTS}
      <div class="agc-card__main">
        {FOLDER}
        <div class="agc-card__text">
          <h3 class="agc-card__title" id="agency-card-title">{E(title)}</h3>
          <p class="agc-card__desc">{E(T(a['body']))}</p>
        </div>
        <div class="agc-card__cta">
          {link}
          {dark_button(PRIMARY_CTA, "Let's talk", ctx.url('contact'), cls='agc-btn--block')}
        </div>
      </div>
      <div class="agc-card__side">
        {checklist(a['nots'])}
        {note_row(E(T(a['closing'])))}
      </div>
    </article>'''


def _icon_tile(ctx, kind):
    """48 px round icons in the reference slots: a light metallic disc holding the 3D mark (card 2,
    reference gear icon) and a black disc with the flat mark (card 3, reference compass icon)."""
    if kind == '3d':
        return (f'<span class="agc-icon agc-icon--3d">'
                f'{lib.img(ctx, "assets/brand/logo-mark-3d.webp", "", w=34, h=34)}</span>')
    return f'<span class="agc-icon agc-icon--tile" aria-hidden="true">{svg_inline("assets/brand/logo-mark.svg")}</span>'


def _philosophy_card(ctx):
    p = WHO['philosophy']
    return f'''<article class="card agc-card agc-card--tall" aria-labelledby="agency-phil-title">
      {DOTS}
      <div class="agc-card__head">
        {_icon_tile(ctx, '3d')}
        <span class="agc-badge">{GLYPH_STEPS}<span>{E(p['label'])}</span></span>
      </div>
      <div class="agc-card__text">
        <h3 class="agc-card__title" id="agency-phil-title">{E(p['title'])}</h3>
        <p class="agc-card__desc">{E(T(p['body']))}</p>
      </div>
      {checklist(p['steps'], ordered=True)}
      <div class="agc-card__foot">{underline_link('Who we are ->', ctx.url('who-we-are', 'philosophy'), label='Who we are: our philosophy')}</div>
    </article>'''


def _promise_card(ctx):
    p = WHO['promise']
    lines = p['lines']
    ask = lines[-1] if lines and lines[-1].rstrip().endswith(':') else ''
    rest = lines[:-1] if ask else lines
    ask_html = f'<p class="agc-card__ask">{E(T(ask))}</p>' if ask else ''
    return f'''<article class="card agc-card agc-card--tall" aria-labelledby="agency-promise-title">
      {DOTS}
      <div class="agc-card__head">
        {_icon_tile(ctx, 'tile')}
        <span class="agc-badge">{GLYPH_PROMISE}<span>{E(p['label'])}</span></span>
      </div>
      <div class="agc-card__text">
        <h3 class="agc-card__title" id="agency-promise-title">{E(p['title'])}</h3>
      </div>
      <div class="agc-card__block">
        {checklist(rest)}
        {ask_html}
        {note_row(f'<em>{E(T(p["question"]))}</em>', cls='agc-note--q')}
      </div>
      <div class="agc-card__foot">{underline_link('Our promise ->', ctx.url('who-we-are', 'promise'), label='Who we are: our promise')}</div>
    </article>'''


def render(ctx):
    a = HOME['agency']
    return f'''<section class="agc section" id="agency" aria-labelledby="agency-title">
  <div class="agc__inner">
    <header class="section-head agc__head">
      {pill_label(a['label'])}
      <h2 class="section-head__title agc__title" id="agency-title" data-split>{E(T(a['title']))}</h2>
      <p class="section-head__sub agc__sub" data-reveal style="--d:160ms">{E(T(a['kicker']))}</p>
    </header>
    <div class="frame agc__frame" data-reveal style="--y:60px">
      {_wide_card(ctx)}
      <div class="agc__row">
        {_philosophy_card(ctx)}
        {_promise_card(ctx)}
      </div>
    </div>
  </div>
</section>'''
