"""Home — section 1: HERO (reference ref-hero-nav §4–10, gallery tiles after ZIP §4–5).

Structure (reference geometry at 1440):
  lockup   rotating statement pill (brand 3D mark avatar) · H1 · lead + body copy
  CTAs     "Start a Project" (dark, brand-mark lead that opens to "+ You") · "Explore Our Work" (light)
  badge    red pulsing dot + mono tagline
  media    services marquee (48px, horizontal ticker) + 1000px framed 4/3/2-column vertical tickers
           of the supplied project imagery; every tile links through lib.project_tag.

Copy comes from content.py / site.config.json only. The pill rotates brand statements taken
verbatim from the content document (no testimonials, which the document does not supply).
"""
import lib
from lib import E, fmt, CONFIG, button, roll
import content
import projects

HERO = content.HOME['hero']

# Rotating pill: short brand statements, verbatim from the document / menu artwork.
STATEMENTS = [
    CONFIG['menu_tagline'],                 # "Creativity meets functionality."
    content.HOME['believe']['body'][2],     # "We make complex things feel simple."
    content.HOME['believe']['title'],       # "Simple for people. Powerful for business."
    content.FOOTER['line'],                 # "Digital experiences, built around you."
]

# Gallery columns (reference §8.2): direction, speed px/s, hover factor; tiles = (asset, project slug, aspect).
# Covers (home-NN) and case imagery alternate light/dark and landscape/portrait so neighbouring
# columns never line up the same tone or shape.
L169, L43, SQ, P45 = '16/9', '4/3', '1/1', '4/5'
COLUMNS = [
    ('down', 25, 0.8, [
        ('home-04', 'hocl-labs', L43),
        ('projects-taurus-arena-05', 'taurus-arena', P45),
        ('home-02', 'evermark-global', L169),
        ('projects-fragile-base-04', 'fragile-base', SQ),
        ('home-08', 'tafuta', L43),
    ]),
    ('up', 34, 0.9, [
        ('projects-taurus-arena-01', 'taurus-arena', SQ),
        ('home-01', 'two26-studio', L169),
        ('projects-hocl-labs-01', 'hocl-labs', P45),
        ('home-07', 'aesthetic-origins', '3/2'),
        ('projects-tafuta-09', 'tafuta', SQ),
    ]),
    ('down', 30, 0.9, [
        ('home-09', 'sunnakids', '7/5'),
        ('projects-aesthetic-origins-04', 'aesthetic-origins', P45),
        ('home-05', 'taurus-arena', L169),
        ('projects-fragile-base-08', 'fragile-base', SQ),
        ('projects-hocl-labs-03', 'hocl-labs', L169),
    ]),
    ('up', 25, 0.8, [
        ('home-03', 'risen-social', L43),
        ('projects-tafuta-05', 'tafuta', P45),
        ('home-06', 'fragile-base', L169),
        ('projects-aesthetic-origins-08', 'aesthetic-origins', '5/4'),
        ('home-10', 'real-estate', '3/2'),
    ]),
]

TILE_SIZES = '(min-width:1440px) 316px, (min-width:800px) 30vw, 46vw'


def _typo(text):
    """Typographic apostrophes for display copy (content itself is unchanged)."""
    return text.replace("'", '’')


def _avatar(ctx, cls, size):
    return (f'<span class="{cls}">'
            f'{lib.img(ctx, "assets/brand/logo-mark-3d.webp", "", w=size, h=size, eager=True)}</span>')


def _pill(ctx):
    rows = ''.join(
        f'<span class="hero-pill__row{" is-active" if i == 0 else ""}">'
        f'{_avatar(ctx, "hero-pill__av", 32)}'
        f'<span class="hero-pill__bubble">{E(fmt(s))}</span></span>'
        for i, s in enumerate(STATEMENTS))
    tail = ('<svg class="hero-pill__tail" viewBox="0 0 34 13" aria-hidden="true" focusable="false">'
            '<path d="M9.084 0C8.531 0 8.084.448 8.084 1c0 0 0 0 1.23 0 1.229 0 5.651 8 8.138 8 2.488 0 '
            '6.002-8 7.849-8 1.846 0 1.229 0 1.229 0V0Z" fill="currentColor"/></svg>')
    tip = f'<span class="hero-pill__tip">{E(CONFIG["brand_full"])}{tail}</span>'
    # Decorative: the statements also live in the sections below and the menu artwork.
    return f'<div class="hero-pill" data-hero-pill aria-hidden="true">{rows}{tip}</div>'


def _ctas(ctx):
    lead = (_avatar(ctx, 'hero-cta__av', 28)
            + '<span class="hero-cta__plus">+</span><span class="hero-cta__you">You</span>')
    start = button(ctx, HERO['ctas'][0], ctx.url('contact'), variant='dark', lead=lead, cls='hero-cta hero-cta--start')
    work = button(ctx, HERO['ctas'][1], ctx.url('work'), variant='light', cls='hero-cta hero-cta--work')
    tagline = fmt(CONFIG['tagline']).rstrip('.')
    return f'''<div class="hero__cta">
      <div class="hero__buttons">
        <div class="hero__btn" data-reveal data-appear style="--d:400ms;--y:60px">{start}</div>
        <div class="hero__btn" data-reveal data-appear style="--d:400ms;--y:60px">{work}</div>
      </div>
      <p class="hero-badge" data-reveal data-appear style="--d:500ms;--y:40px">
        <span class="hero-badge__dot" aria-hidden="true"><i></i><i></i></span>
        <span class="hero-badge__text">{E(tagline)}</span>
      </p>
    </div>'''


def _marquee(ctx):
    """Services ticker in the reference logo-marquee slot (spec critic E: Geist 500 20/1 −0.02em at
    .40, a 12px brand mark at .35 between words). Decorative, like the reference's faded logo wall:
    the same services are listed in the What We Create section and the footer, so it is hidden from
    assistive tech instead of being read as a moving list."""
    mark = lib.svg_inline('assets/brand/logo-mark.svg', 'hero-marquee__mark')
    items = ''.join(
        f'<li class="hero-marquee__item"><span class="hero-marquee__word">{E(s)}</span>{mark}</li>'
        for s in content.FOOTER['services'])
    return (f'<div class="hero-marquee" data-reveal="fade" data-appear style="--d:600ms" aria-hidden="true">'
            f'<div class="hero-marquee__track" data-ticker data-direction="left" data-speed="25">'
            f'<ul class="hero-marquee__list" data-ticker-list role="list">{items}</ul>'
            f'</div></div>')


def _tile(ctx, asset, slug, ar, seen):
    p = projects.by_slug(slug)
    title, industry = p['title'], p['industry']
    # One keyboard/screen-reader stop per project: repeat tiles stay clickable but are skipped.
    extra = 'tabindex="-1" aria-hidden="true"' if slug in seen else ''
    seen.add(slug)
    open_tag, close_tag = lib.project_tag(ctx, p, 'hero-tile', extra=extra)
    alt = f'{title} — {industry} project imagery'
    img = lib.picture(ctx, asset, alt, sizes=TILE_SIZES, max_width=1280)
    cap = (f'<span class="hero-tile__cap" aria-hidden="true">'
           f'<span class="hero-tile__title">{roll(title)}</span>'
           f'<span class="hero-tile__dot">·</span>'
           f'<span class="hero-tile__ind">{roll(industry)}</span></span>')
    return (f'<li class="hero-col__item">{open_tag}'
            f'<span class="hero-tile__media reveal-image" style="--ar:{ar}">{img}</span>{cap}'
            f'{close_tag}</li>')


def _gallery(ctx):
    cols, seen = [], set()
    for n, (direction, speed, hover, tiles) in enumerate(COLUMNS, 1):
        items = ''.join(_tile(ctx, *t, seen) for t in tiles)
        cols.append(
            f'<div class="hero-col hero-col--{n}" data-ticker data-direction="{direction}" data-speed="{speed}" data-hover="{hover}">'
            f'<ul class="hero-col__list" data-ticker-list role="list">{items}</ul></div>')
    handles = ''.join(f'<i class="hero-gallery__handle hero-gallery__handle--{c}" aria-hidden="true"></i>' for c in ('tl', 'tr', 'bl', 'br'))
    # WCAG 2.2.2: the gallery, marquee and statement pill move indefinitely, so the hero carries a
    # pause control (shown by 20-hero.js only when motion is on; sticky below the header while
    # the frame is on screen). First in the frame so keyboard users reach it before the tiles.
    control = ('<div class="hero-gallery__ui"><button class="hero-motion" type="button" data-hero-motion hidden>'
               '<span class="hero-motion__ic" aria-hidden="true"><i></i><i></i></span>'
               '<span class="hero-motion__label" data-hero-motion-label>Pause motion</span></button></div>')
    return (f'<div class="hero-gallery" data-hero-gallery role="group" aria-label="Selected projects">'
            f'{control}{"".join(cols)}{handles}</div>')


def render(ctx):
    return f'''<section class="hero section" id="hero" aria-labelledby="hero-title">
  <div class="hero__inner">
    <div class="hero__lockup">
      {_pill(ctx)}
      <h1 class="hero__title" id="hero-title" data-reveal data-appear style="--d:200ms;--y:80px">{E(_typo(HERO["title"]))}</h1>
      <div class="hero__copy" data-reveal data-appear style="--d:300ms;--y:80px">
        <p class="hero__lead">{E(fmt(HERO["lead"]))}</p>
        <p class="hero__body">{E(fmt(HERO["body"]))}</p>
      </div>
    </div>
    {_ctas(ctx)}
  </div>
  <div class="hero__media">
    {_marquee(ctx)}
    {_gallery(ctx)}
  </div>
</section>'''
