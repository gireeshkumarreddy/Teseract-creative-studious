"""Static checks for dist/ (adapted from the ZIP project's check.py).

Verifies: route coverage, exactly one <h1> per page, unique ids, every local src/href/srcset
target and #fragment exists, image alt text and responsive attributes, safe external links,
CSS url() assets, reduced-motion support, no leftover build errors / stubs / third-party identity.

    python scripts/check.py [--dist DIR]
"""
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlsplit, unquote
import json, re, sys

ROOT = Path(__file__).resolve().parents[1]
DIST = Path(sys.argv[sys.argv.index('--dist') + 1]).resolve() if '--dist' in sys.argv else ROOT / 'dist'
sys.path.insert(0, str(ROOT / 'scripts'))
import projects  # noqa: E402
import lib  # noqa: E402  (longpath: the workspace path can exceed Windows MAX_PATH)

errors, warnings = [], []
pages = sorted(DIST.rglob('*.html'))
FORBIDDEN = ['zzstudio', 'ZZStudio', 'ZzStudio', 'AgenQ', 'Abdul Mutakabar', 'ayzz', 'Budarina', 'budarina', 'Sesteem', 'cal.com']


class Page(HTMLParser):
    def __init__(self):
        super().__init__()
        self.refs, self.images, self.ids, self.tags, self.h1 = [], [], [], [], 0

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        self.tags.append((tag, a))
        if tag == 'h1':
            self.h1 += 1
        if a.get('id'):
            self.ids.append(a['id'])
        for key in ('src', 'href'):
            if a.get(key) and not (tag == 'a' and a.get('aria-disabled') == 'true'):
                self.refs.append(a[key])
        if a.get('srcset'):
            self.refs.extend(part.strip().split()[0] for part in a['srcset'].split(','))
        if tag == 'img':
            self.images.append(a)


for p in pages:
    html = lib.longpath(p).read_text(encoding='utf-8')
    page = Page()
    page.feed(html)
    rel = p.relative_to(DIST).as_posix()
    if page.h1 != 1:
        errors.append(f'{rel}: expected one h1, got {page.h1}')
    dupes = {i for i in page.ids if page.ids.count(i) > 1}
    if dupes:
        errors.append(f'{rel}: duplicate ids {sorted(dupes)}')
    if 'build-error' in html and 'class="build-error"' in html:
        errors.append(f'{rel}: contains a build-error block')
    if 'class="section stub"' in html:
        errors.append(f'{rel}: contains a stub section')
    for word in FORBIDDEN:
        if word in html:
            errors.append(f'{rel}: contains third-party identity text "{word}"')
    for ref in page.refs:
        u = urlsplit(ref)
        if u.scheme or u.netloc:
            continue
        if u.path:
            target = (p.parent / unquote(u.path)).resolve()
            if not lib.longpath(target).exists():
                errors.append(f'{rel}: missing {ref}')
        elif u.fragment and u.fragment not in page.ids:
            errors.append(f'{rel}: missing fragment {ref}')
    for img in page.images:
        if 'alt' not in img:
            errors.append(f'{rel}: image without alt ({img.get("src")})')
        if img.get('srcset') and not all(img.get(k) for k in ['width', 'height', 'sizes']):
            errors.append(f'{rel}: incomplete responsive image {img.get("src")}')
    for tag, a in page.tags:
        if tag == 'a' and a.get('target') == '_blank' and 'noopener' not in (a.get('rel') or ''):
            errors.append(f'{rel}: unsafe external target {a.get("href")}')
        if tag == 'a' and not a.get('href'):
            errors.append(f'{rel}: <a> without href')
    print('PASS' if not any(e.startswith(rel + ':') for e in errors) else 'FAIL', rel, 'images', len(page.images))

expected = ['index.html', '404.html', '404/index.html'] + [f'{r}/index.html' for r in
            ['who-we-are', 'what-we-create', 'our-approach', 'work', 'client-stories', 'contact', 'privacy', 'terms']]
expected += [f"{p['route']}/index.html" for p in projects.CASES]
for route in expected:
    if not lib.longpath(DIST / route).is_file():
        errors.append(f'Missing route {route}')

css = (DIST / 'styles.css').read_text(encoding='utf-8')
for asset in re.findall(r"url\(['\"]?(\./assets/[^'\")]+)", css):
    if not lib.longpath(DIST / asset).exists():
        errors.append(f'Missing CSS asset {asset}')
if 'prefers-reduced-motion' not in css:
    errors.append('styles.css has no prefers-reduced-motion handling')
report = json.loads((DIST / 'build-report.json').read_text(encoding='utf-8')) if (DIST / 'build-report.json').exists() else {}
for f in report.get('failures', []):
    errors.append(f"build failure: {f['module']} {f['func']}")

summary = {'routes': len(expected), 'html_files': len(pages), 'errors': errors, 'warnings': warnings}
(ROOT / 'docs').mkdir(exist_ok=True)
(ROOT / 'docs/static-check-results.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary, indent=2))
if errors:
    raise SystemExit(1)
