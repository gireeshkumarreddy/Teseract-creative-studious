"""Shared build helpers (Python 3 standard library only).

Every page/section renderer receives a Ctx and returns an HTML string. Use the helpers
here for anything that touches URLs or assets so that:
  * relative links work from file:// as well as any static host (ZIP convention), and
  * only the assets that are actually referenced get copied into dist/.
"""
import datetime, html, json, pathlib, re

ROOT = pathlib.Path(__file__).resolve().parents[1]
PUBLIC = ROOT / 'public'
DIST = ROOT / 'dist'
CONFIG = json.loads((ROOT / 'site.config.json').read_text(encoding='utf-8'))
BRAND = CONFIG['brand']
YEAR = datetime.date.today().year
ASSETS = {a['name']: a for a in json.loads((ROOT / 'scripts/asset-manifest.json').read_text(encoding='utf-8'))}
USED = set()          # paths relative to public/, e.g. 'assets/home-01-1280.webp'
FAILURES = []         # (module, func, traceback) collected during a build
E = html.escape


def longpath(path):
    """Windows extended-length path (the packaged workspace path can exceed MAX_PATH)."""
    import os
    if os.name != 'nt':
        return pathlib.Path(path)
    p = str(pathlib.Path(path).absolute())
    prefix = '\\\\?\\'
    return pathlib.Path(p if p.startswith(prefix) else prefix + p)


def fmt(text):
    """Substitute {brand}/{year} placeholders in copy."""
    return text.replace('{brand}', BRAND).replace('{year}', str(YEAR))


class Ctx:
    def __init__(self, route, page):
        self.route = route.strip('/')                       # '' for home, 'work', 'projects/tafuta'
        self.page = page                                    # page key, e.g. 'home', 'work', 'project'
        depth = 0 if not self.route else self.route.count('/') + 1
        self.base = '../' * depth or './'

    def url(self, route, frag=''):
        route = route.strip('/')
        path = self.base + (route + '/index.html' if route else 'index.html')
        return path + (('#' + frag) if frag else '')

    def asset(self, file):
        """Reference a file under public/ (e.g. 'assets/brand/logo-mark.svg')."""
        USED.add(file)
        return self.base + file


def picture(ctx, name, alt, *, sizes='100vw', eager=False, cls='', attrs='', max_width=None):
    """Responsive <img> for a manifest asset (rasters get srcset, vectors a plain img)."""
    a = ASSETS[name]
    c = f' class="{cls}"' if cls else ''
    if 'file' in a:
        return f'<img{c} src="{ctx.asset(a["file"])}" alt="{E(alt)}" loading="lazy" decoding="async"{(" " + attrs) if attrs else ""}>'
    variants = [v for v in a['variants'] if not max_width or v['width'] <= max_width] or a['variants'][:1]
    for v in variants:
        USED.add(v['file'])
    default = next((v for v in variants if v['width'] >= 1280), variants[-1])
    srcset = ', '.join(f'{ctx.base}{v["file"]} {v["width"]}w' for v in variants)
    pri = ' fetchpriority="high"' if eager else ''
    return (f'<img{c} src="{ctx.base}{default["file"]}" srcset="{srcset}" sizes="{sizes}" '
            f'width="{a["native_width"]}" height="{a["native_height"]}" alt="{E(alt)}" '
            f'loading="{"eager" if eager else "lazy"}" decoding="async"{pri}{(" " + attrs) if attrs else ""}>')


def ratio(name):
    a = ASSETS[name]
    return f'{a["native_width"]}/{a["native_height"]}'


def img(ctx, file, alt, *, w=None, h=None, cls='', eager=False, attrs=''):
    """<img> for a non-manifest local asset under public/."""
    size = (f' width="{w}"' if w else '') + (f' height="{h}"' if h else '')
    c = f' class="{cls}"' if cls else ''
    return (f'<img{c} src="{ctx.asset(file)}" alt="{E(alt)}"{size} loading="{"eager" if eager else "lazy"}" '
            f'decoding="async"{(" " + attrs) if attrs else ""}>')


def roll(text):
    """Letter-roll hover text (ZIP pattern). Put the accessible name on the parent."""
    t = E(text)
    return f'<span class="roll" aria-hidden="true"><span>{t}</span><span>{t}</span></span>'


ICONS = {
    'arrow-ne': '<svg viewBox="0 0 16 16" aria-hidden="true" focusable="false"><path d="M4.5 11.5 11.5 4.5M5.5 4.5h6v6" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    'arrow-r': '<svg viewBox="0 0 16 16" aria-hidden="true" focusable="false"><path d="M2.5 8h11M9 3.5 13.5 8 9 12.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    'plus': '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 4v16M4 12h16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
    'close': '<svg viewBox="0 0 48 48" aria-hidden="true" focusable="false"><path d="M10 10 38 38M38 10 10 38" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg>',
    'menu': '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M3 8.5h18M3 15.5h18" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
    'check': '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="m5.5 10.4 2.9 2.9 6.1-6.6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    'star': '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="m10 1.8 2.5 5.2 5.7.8-4.1 4 1 5.7L10 14.8l-5.1 2.7 1-5.7-4.1-4 5.7-.8z" fill="currentColor"/></svg>',
    'mail': '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><rect x="2.5" y="4.5" width="15" height="11" rx="2" fill="none" stroke="currentColor" stroke-width="1.5"/><path d="m3.5 6 6.5 5 6.5-5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
}


def icon(name, cls='icon'):
    return f'<span class="{cls} {cls}--{name}">{ICONS[name]}</span>'


def mark(ctx, cls='brand-mark-img', alt=''):
    """Flat brand mark (inline-able via <img>; colour baked in SVG)."""
    return img(ctx, 'assets/brand/logo-mark.svg', alt, w=32, h=32, cls=cls)


def button(ctx, text, href, *, variant='dark', icon_name=None, lead=None, external=False, cls='', attrs=''):
    """Pill button. variant: dark | light | outline | ghost. lead: HTML placed before the label
    (e.g. the brand-mark avatar like the reference's 'Contact' button)."""
    ext = ' target="_blank" rel="noopener"' if external else ''
    lead_html = f'<span class="btn__lead" aria-hidden="true">{lead}</span>' if lead else ''
    ic = f'<span class="btn__icon" aria-hidden="true">{ICONS[icon_name]}</span>' if icon_name else ''
    return (f'<a class="btn btn--{variant}{(" " + cls) if cls else ""}" href="{E(href)}" aria-label="{E(text)}"{ext}'
            f'{(" " + attrs) if attrs else ""}>{lead_html}<span class="btn__label">{roll(text)}</span>{ic}</a>')


def pill_label(text, *, tone='dark', cls=''):
    """Reference section label: dark pill with a small ring dot either side."""
    return (f'<span class="pill-label pill-label--{tone}{(" " + cls) if cls else ""}" data-reveal>'
            f'<i aria-hidden="true"></i><span>{E(text)}</span><i aria-hidden="true"></i></span>')


def section_head(label, title_html, *, sub_html=None, align='center', tag='h2', cls='', title_cls=''):
    """Reference section header: pill label, large tight heading, optional sub copy.
    title_html is trusted HTML (may contain <em>, <s>, <br>)."""
    sub = f'<p class="section-head__sub" data-reveal style="--d:160ms">{sub_html}</p>' if sub_html else ''
    lab = pill_label(label) if label else ''
    return (f'<header class="section-head section-head--{align}{(" " + cls) if cls else ""}">{lab}'
            f'<{tag} class="section-head__title{(" " + title_cls) if title_cls else ""}" data-split>{title_html}</{tag}>{sub}</header>')


def chip(text, cls=''):
    return f'<li class="chip{(" " + cls) if cls else ""}">{E(text)}</li>'


def ext_link(href):
    return ' target="_blank" rel="noopener"' if href.startswith('http') else ''


def social_href(key):
    """Configured social URL or '' when not yet supplied (renders as a disabled link)."""
    return (CONFIG.get('socials') or {}).get(key) or ''


def write(route, body):
    dest = longpath(DIST / (route + '/index.html' if route else 'index.html'))
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(body, encoding='utf-8')


def strip_ws(s):
    return re.sub(r'>\s+<', '><', s)


def project_href(ctx, p):
    """Destination of a project: its case-study page, the live client site, or None."""
    if p['kind'] == 'case':
        return ctx.url(p['route'])
    if p['kind'] == 'external':
        return p['url']
    return None


def project_tag(ctx, p, cls, *, label=None, extra=''):
    """Opening/closing tag pair for a project tile: <a> with the View Project cursor when the
    project has a destination, otherwise a plain <div>. Returns (open, close)."""
    href = project_href(ctx, p)
    if not href:
        return f'<div class="{cls} is-static"{(" " + extra) if extra else ""}>', '</div>'
    external = p['kind'] == 'external'
    name = label or (f"Visit {p['title']} (opens in a new tab)" if external else f"View project: {p['title']}")
    cursor = 'Visit Site' if external else 'View Project'
    return (f'<a class="{cls}" href="{E(href)}" aria-label="{E(name)}" data-cursor="{cursor}"'
            f'{" data-cursor-external=true" if external else ""}{ext_link(href)}{(" " + extra) if extra else ""}>', '</a>')


_SVG_CACHE = {}


def svg_inline(file, cls='', label=None):
    """Inline an SVG from public/ so it inherits currentColor (e.g. the brand mark/wordmark in dark
    contexts). Decorative unless a label is given."""
    if file not in _SVG_CACHE:
        raw = longpath(PUBLIC / file).read_text(encoding='utf-8')
        raw = re.sub(r'<\?xml[^>]*>\s*', '', raw)
        raw = re.sub(r'<title>.*?</title>', '', raw, flags=re.S)
        raw = re.sub(r'\s(role|aria-label|aria-hidden|width|height)="[^"]*"', '', raw, count=0)
        _SVG_CACHE[file] = raw
    raw = _SVG_CACHE[file]
    a11y = f' role="img" aria-label="{E(label)}"' if label else ' aria-hidden="true" focusable="false"'
    c = f' class="{cls}"' if cls else ''
    return raw.replace('<svg', f'<svg{c}{a11y}', 1)
